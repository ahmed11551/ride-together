# 🔌 REG.RU CloudVPS API - Руководство

## 📚 Документация API

**Официальная документация:** https://developers.cloudvps.reg.ru/

**Swagger документация:**
- API v1: https://developers.cloudvps.reg.ru/swagger/v1
- API v2: https://developers.cloudvps.reg.ru/swagger/v2

---

## 🔑 Получение токена

1. Войдите в личный кабинет REG.RU
2. Перейдите в раздел **API** или **Настройки безопасности**
3. Создайте новый API токен
4. Сохраните токен в `.env.regru.token`:
   ```bash
   echo "REG_RU_API_TOKEN=your-token-here" > .env.regru.token
   ```

---

## 🛠️ Использование API клиента

Скрипт: `scripts/regru-api-client.sh`

### Базовые команды:

```bash
# Проверка авторизации
./scripts/regru-api-client.sh check

# Получить список тарифов
./scripts/regru-api-client.sh tariffs

# Получить список образов (ОС)
./scripts/regru-api-client.sh images

# Получить список серверов
./scripts/regru-api-client.sh servers

# Информация о сервере
./scripts/regru-api-client.sh server <server_id>

# Создать сервер (требует оплаты!)
./scripts/regru-api-client.sh create-server "ride-backend" <tariff_id> <image_id>

# Управление сервером
./scripts/regru-api-client.sh start <server_id>
./scripts/regru-api-client.sh stop <server_id>
./scripts/regru-api-client.sh restart <server_id>
```

---

## 📋 Примеры использования

### 1. Проверка доступных тарифов

```bash
./scripts/regru-api-client.sh tariffs | jq '.'
```

Пример ответа:
```json
{
  "tariffs": [
    {
      "id": 123,
      "name": "Basic",
      "cpu": 2,
      "ram": 2048,
      "disk": 20,
      "price": 350
    }
  ]
}
```

### 2. Получение списка образов

```bash
./scripts/regru-api-client.sh images | jq '.'
```

Найдите Ubuntu 22.04 и запишите `id`.

### 3. Создание сервера

```bash
# Сначала получите tariff_id и image_id
./scripts/regru-api-client.sh tariffs
./scripts/regru-api-client.sh images

# Создать сервер
./scripts/regru-api-client.sh create-server "ride-backend" 123 456
```

⚠️ **ВНИМАНИЕ:** Создание сервера требует оплаты!

### 4. Полная автоматизация

```bash
./scripts/full-auto-regru.sh
```

Скрипт поможет:
- Проверить авторизацию
- Получить список тарифов и образов
- Создать VPS (если нужно)
- Настроить всё автоматически

---

## 🔧 API Endpoints (основные)

### Управление серверами

```
GET    /v1/servers              - Список серверов
GET    /v1/servers/{id}         - Информация о сервере
POST   /v1/servers              - Создать сервер
POST   /v1/servers/{id}/action  - Действие (start/stop/restart)
DELETE /v1/servers/{id}         - Удалить сервер
```

### Тарифы и образы

```
GET    /v1/tariffs              - Список тарифов
GET    /v1/images               - Список образов
```

### Снэпшоты

```
GET    /v1/snapshots            - Список снэпшотов
POST   /v1/snapshots            - Создать снэпшот
POST   /v1/snapshots/{id}/restore - Восстановить из снэпшота
```

### SSH ключи

```
GET    /v1/ssh-keys             - Список SSH ключей
POST   /v1/ssh-keys             - Добавить SSH ключ
```

---

## 📝 Пример создания сервера через API

### Шаг 1: Получить тарифы и образы

```bash
# Тарифы
./scripts/regru-api-client.sh tariffs | jq '.tariffs[] | {id, name, cpu, ram, disk, price}'

# Образы (найти Ubuntu 22.04)
./scripts/regru-api-client.sh images | jq '.images[] | select(.name | contains("Ubuntu 22"))'
```

### Шаг 2: Создать сервер

```bash
# Пример: создать сервер с Ubuntu 22.04, 2 vCPU, 2GB RAM
./scripts/regru-api-client.sh create-server "ride-backend" 123 456
```

Ответ:
```json
{
  "server": {
    "id": 789,
    "name": "ride-backend",
    "ip": "123.45.67.89",
    "status": "creating"
  }
}
```

### Шаг 3: Дождаться готовности и настроить

```bash
# Проверить статус
./scripts/regru-api-client.sh server 789

# Когда status = "running", настроить
./scripts/auto-setup-regru.sh 123.45.67.89 root
```

---

## 🔐 Авторизация

Все запросы требуют токен в заголовке:
```
Authorization: Bearer YOUR_API_TOKEN
```

Токен должен быть сохранен в `.env.regru.token`:
```bash
REG_RU_API_TOKEN=your-token-here
```

---

## 🚀 Полная автоматизация

Используйте скрипт для полной автоматизации:

```bash
./scripts/full-auto-regru.sh
```

Он предложит:
1. Использовать существующий VPS
2. Создать VPS через API
3. Показать инструкцию по ручному созданию

---

## 📚 Полезные ссылки

- **API Документация:** https://developers.cloudvps.reg.ru/
- **Swagger v1:** https://developers.cloudvps.reg.ru/swagger/v1
- **Swagger v2:** https://developers.cloudvps.reg.ru/swagger/v2

---

## ✅ Готово!

API клиент готов к использованию. Проверьте доступные команды:

```bash
./scripts/regru-api-client.sh
```

