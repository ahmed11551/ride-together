# 📡 Timeweb Cloud API - Возможности для проекта

## 🎯 Что это дает?

OpenAPI спецификация Timeweb Cloud API позволяет **программно управлять инфраструктурой** через API, а не только через веб-интерфейс.

---

## ✅ Полезные возможности для Ride Together

### 1. **Автоматизация деплоя** 🔄

Вместо ручного создания ресурсов в панели управления, можно автоматизировать:

```bash
# Автоматическое создание базы данных
curl -X POST \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"preset_id": 443, "type": "postgresql", "name": "ride-together-db"}' \
  https://api.timeweb.cloud/api/v1/databases

# Автоматическое создание сервера для backend
curl -X POST \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"os_id": 123, "preset_id": 456, "name": "ride-backend"}' \
  https://api.timeweb.cloud/api/v1/servers

# Автоматическое создание статического хостинга для frontend
# (через соответствующий endpoint)
```

**Преимущества:**
- ✅ Скрипт развертывания одной командой
- ✅ Воспроизводимость (одинаковая конфигурация каждый раз)
- ✅ CI/CD интеграция
- ✅ Меньше человеческих ошибок

---

### 2. **Мониторинг ресурсов** 📊

Проверка статуса и мониторинг ресурсов:

```bash
# Проверить статус базы данных
curl -X GET \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/databases/{db_id}

# Проверить статус сервера
curl -X GET \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/servers/{server_id}

# Получить информацию о балансе
curl -X GET \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/account/finances
```

**Полезно для:**
- ✅ Health checks
- ✅ Автоматические алерты
- ✅ Мониторинг стоимости
- ✅ Проверка доступности

---

### 3. **Управление доменами** 🌐

Автоматическое управление DNS и доменами:

```bash
# Создать DNS запись
curl -X POST \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"type": "A", "name": "api", "value": "1.2.3.4"}' \
  https://api.timeweb.cloud/api/v1/domains/{domain_id}/dns

# Обновить DNS запись
curl -X PATCH \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"value": "5.6.7.8"}' \
  https://api.timeweb.cloud/api/v1/domains/{domain_id}/dns/{record_id}
```

**Полезно для:**
- ✅ Автоматическая настройка поддоменов
- ✅ Динамическое обновление DNS
- ✅ Управление SSL сертификатами

---

### 4. **Управление бэкапами** 💾

Автоматическое создание и управление бэкапами:

```bash
# Создать бэкап базы данных
curl -X POST \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/databases/{db_id}/backups

# Восстановить из бэкапа
curl -X POST \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"backup_id": 123}' \
  https://api.timeweb.cloud/api/v1/databases/{db_id}/restore
```

**Полезно для:**
- ✅ Автоматические ежедневные бэкапы
- ✅ Восстановление после ошибок
- ✅ Тестирование на копиях

---

### 5. **Масштабирование** 📈

Автоматическое масштабирование ресурсов:

```bash
# Изменить размер базы данных (если поддерживается)
curl -X PATCH \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"preset_id": 444}' \
  https://api.timeweb.cloud/api/v1/databases/{db_id}

# Изменить конфигурацию сервера
curl -X PATCH \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"preset_id": 457}' \
  https://api.timeweb.cloud/api/v1/servers/{server_id}
```

**Полезно для:**
- ✅ Автомасштабирование при нагрузке
- ✅ Уменьшение ресурсов в нерабочее время
- ✅ Автоматическая оптимизация стоимости

---

## 🔧 Как использовать в проекте

### Вариант 1: Скрипты деплоя

Создать скрипт для автоматического деплоя:

```bash
#!/bin/bash
# scripts/deploy-infrastructure.sh

TIMEWEB_TOKEN=${TIMEWEB_CLOUD_TOKEN}

# 1. Создать базу данных (если нужно)
DB_RESPONSE=$(curl -X POST \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  -d '{"preset_id": 443, "type": "postgresql", "name": "ride-db"}' \
  https://api.timeweb.cloud/api/v1/databases)

DB_ID=$(echo $DB_RESPONSE | jq -r '.db.id')

# 2. Получить connection string
DB_INFO=$(curl -X GET \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/databases/$DB_ID)

# 3. Применить схему БД
# ... применить TIMEWEB_FULL_SCHEMA.sql

# 4. Создать/обновить backend приложение
# ... через API (если поддерживается)

# 5. Создать/обновить frontend приложение
# ... через API (если поддерживается)
```

### Вариант 2: CI/CD интеграция

Использовать в GitHub Actions или GitLab CI:

```yaml
# .github/workflows/deploy.yml
name: Deploy to Timeweb

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Check database status
        run: |
          curl -X GET \
            -H "Authorization: Bearer ${{ secrets.TIMEWEB_TOKEN }}" \
            https://api.timeweb.cloud/api/v1/databases/{db_id}
      
      - name: Deploy backend
        # ... деплой backend
      
      - name: Deploy frontend
        # ... деплой frontend
```

### Вариант 3: Мониторинг скрипт

Создать скрипт для мониторинга:

```javascript
// scripts/monitor-timeweb.js
const axios = require('axios');

async function checkResources() {
  const token = process.env.TIMEWEB_CLOUD_TOKEN;
  
  // Проверить статус БД
  const dbStatus = await axios.get(
    'https://api.timeweb.cloud/api/v1/databases/{db_id}',
    { headers: { Authorization: `Bearer ${token}` } }
  );
  
  console.log('Database status:', dbStatus.data.db.status);
  
  // Проверить баланс
  const finances = await axios.get(
    'https://api.timeweb.cloud/api/v1/account/finances',
    { headers: { Authorization: `Bearer ${token}` } }
  );
  
  console.log('Balance:', finances.data.finances.balance);
  
  // Проверить статус серверов
  const servers = await axios.get(
    'https://api.timeweb.cloud/api/v1/servers',
    { headers: { Authorization: `Bearer ${token}` } }
  );
  
  servers.data.servers.forEach(server => {
    console.log(`Server ${server.name}: ${server.status}`);
  });
}

checkResources();
```

---

## 📋 Доступные endpoints (из OpenAPI)

Основные категории API:

### ✅ Базы данных (`/api/v1/databases`)
- `GET /databases` - список БД
- `POST /databases` - создать БД
- `GET /databases/{id}` - получить БД
- `PATCH /databases/{id}` - обновить БД
- `DELETE /databases/{id}` - удалить БД
- `POST /databases/{id}/backups` - создать бэкап
- `POST /databases/{id}/restore` - восстановить

### ✅ Облачные серверы (`/api/v1/servers`)
- `GET /servers` - список серверов
- `POST /servers` - создать сервер
- `GET /servers/{id}` - получить сервер
- `PATCH /servers/{id}` - обновить сервер
- `DELETE /servers/{id}` - удалить сервер

### ✅ Домены (`/api/v1/domains`)
- `GET /domains` - список доменов
- `POST /domains/{id}/dns` - создать DNS запись
- `PATCH /domains/{id}/dns/{record_id}` - обновить DNS

### ✅ Аккаунт
- `GET /account/finances` - финансовая информация
- `GET /account/services/cost` - стоимость сервисов

### ✅ И многое другое...
- Балансировщики нагрузки
- Образы серверов
- SSH ключи
- Проекты
- И т.д.

---

## 🔑 Как получить API токен

1. Войдите в панель управления Timeweb Cloud
2. Перейдите в раздел **"API и Terraform"**
3. Создайте новый токен
4. Сохраните токен в переменную окружения:
   ```bash
   export TIMEWEB_CLOUD_TOKEN="your-token-here"
   ```

⚠️ **Важно:** Храните токен в секретах, не коммитьте в Git!

---

## 💡 Практические примеры для Ride Together

### Пример 1: Проверка готовности инфраструктуры

```bash
#!/bin/bash
# scripts/check-infrastructure.sh

TIMEWEB_TOKEN=${TIMEWEB_CLOUD_TOKEN}
DB_ID=${TIMEWEB_DB_ID}

# Проверить, что БД запущена
DB_STATUS=$(curl -s -X GET \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/databases/$DB_ID | jq -r '.db.status')

if [ "$DB_STATUS" != "running" ]; then
  echo "❌ Database is not running (status: $DB_STATUS)"
  exit 1
fi

echo "✅ Database is running"

# Проверить баланс
BALANCE=$(curl -s -X GET \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/account/finances | jq -r '.finances.balance')

echo "💰 Balance: $BALANCE ₽"
```

### Пример 2: Автоматический бэкап

```bash
#!/bin/bash
# scripts/backup-database.sh

TIMEWEB_TOKEN=${TIMEWEB_CLOUD_TOKEN}
DB_ID=${TIMEWEB_DB_ID}

echo "Creating backup..."
BACKUP_RESPONSE=$(curl -s -X POST \
  -H "Authorization: Bearer $TIMEWEB_TOKEN" \
  https://api.timeweb.cloud/api/v1/databases/$DB_ID/backups)

BACKUP_ID=$(echo $BACKUP_RESPONSE | jq -r '.backup.id')
echo "✅ Backup created: $BACKUP_ID"
```

### Пример 3: Мониторинг стоимости

```javascript
// scripts/monitor-costs.js
const axios = require('axios');

async function monitorCosts() {
  const token = process.env.TIMEWEB_CLOUD_TOKEN;
  
  const response = await axios.get(
    'https://api.timeweb.cloud/api/v1/account/services/cost',
    { headers: { Authorization: `Bearer ${token}` } }
  );
  
  const costs = response.data.costs;
  
  console.log('📊 Service Costs:');
  costs.forEach(cost => {
    console.log(`  ${cost.name}: ${cost.price} ₽/${cost.period}`);
  });
  
  // Отправить алерт, если стоимость выше лимита
  const totalCost = costs.reduce((sum, cost) => sum + parseFloat(cost.price), 0);
  if (totalCost > 1000) {
    console.warn('⚠️  Total cost exceeds 1000₽!');
    // Отправить уведомление...
  }
}

monitorCosts();
```

---

## 🎯 Рекомендации

### Что стоит автоматизировать:
1. ✅ **Проверка готовности** перед деплоем
2. ✅ **Создание бэкапов** на регулярной основе
3. ✅ **Мониторинг статуса** ресурсов
4. ✅ **Проверка баланса** перед операциями
5. ✅ **DNS управление** для поддоменов

### Что можно делать вручную:
- Первоначальная настройка (один раз)
- Изменение конфигурации (редко)
- Управление через веб-интерфейс (удобнее)

---

## 📚 Полезные ссылки

- OpenAPI спецификация: `/Users/ahmeddevops/Downloads/openapi.json`
- Timeweb Cloud API документация: https://timeweb.cloud/api/docs
- Официальная документация: https://timeweb.cloud/docs

---

## ⚠️ Важные замечания

1. **Rate Limiting**: Максимум 20 запросов в секунду на endpoint
2. **Безопасность**: Храните токены в секретах
3. **Обработка ошибок**: Всегда проверяйте статус ответа
4. **Асинхронность**: Некоторые операции выполняются асинхронно (проверяйте статус)

---

## 🚀 Следующие шаги

1. Получить API токен в Timeweb Dashboard
2. Создать скрипт проверки инфраструктуры
3. Интегрировать в CI/CD (если нужно)
4. Настроить мониторинг стоимости

**Это открывает возможности для полной автоматизации инфраструктуры!** 🎉

