import { useMemo, useEffect, useRef, useState } from 'react';
import { MapPin, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import type { RideWithDriver } from '@/hooks/useRides';
import { getCityCoordinates } from '@/lib/geocoding';
import { buildRoute, formatDistance, formatDuration } from '@/lib/routing';
import { env } from '@/lib/env';
import type { YandexMapsAPI, YandexMapsMap, YandexMapsPlacemark, YandexMapsPolyline } from '@/lib/yandex-maps-types';

const YANDEX_MAPS_API_KEY = env.VITE_YANDEX_MAPS_API_KEY || '';

interface RidesMapProps {
  rides: RideWithDriver[];
  height?: string;
  className?: string;
}

declare global {
  interface Window {
    ymaps: YandexMapsAPI;
  }
}

export const RidesMap = ({ rides, height = '500px', className = '' }: RidesMapProps) => {
  const navigate = useNavigate();
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<YandexMapsMap | null>(null);
  const markersRef = useRef<YandexMapsPlacemark[]>([]);
  const routesRef = useRef<YandexMapsPolyline[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  const markers = useMemo(() => {
    return rides
      .map((ride) => {
        const fromCoords = getCityCoordinates(ride.from_city);
        const toCoords = getCityCoordinates(ride.to_city);

        if (!fromCoords || !toCoords) return null;

        return {
          ride,
          fromCoords,
          toCoords,
          centerCoords: {
            lat: (fromCoords.lat + toCoords.lat) / 2,
            lng: (fromCoords.lng + toCoords.lng) / 2,
          },
        };
      })
      .filter(Boolean) as Array<{
      ride: RideWithDriver;
      fromCoords: { lat: number; lng: number };
      toCoords: { lat: number; lng: number };
      centerCoords: { lat: number; lng: number };
    }>;
  }, [rides]);

  const centerCoords = useMemo(() => {
    if (markers.length === 0) {
      return { lat: 55.7558, lng: 37.6173, zoom: 5 }; // Москва по умолчанию
    }

    if (markers.length === 1) {
      return {
        ...markers[0].centerCoords,
        zoom: 8,
      };
    }

    // Вычисляем центр всех маркеров
    const avgLat =
      markers.reduce((sum, m) => sum + m.centerCoords.lat, 0) / markers.length;
    const avgLng =
      markers.reduce((sum, m) => sum + m.centerCoords.lng, 0) / markers.length;

    return {
      lat: avgLat,
      lng: avgLng,
      zoom: 6,
    };
  }, [markers]);

  // Загрузка Yandex Maps API
  useEffect(() => {
    if (!YANDEX_MAPS_API_KEY) {
      return;
    }

    if (window.ymaps) {
      window.ymaps.ready(() => setIsLoaded(true));
      return;
    }

    // Загружаем Yandex Maps API с defer для оптимизации
    const script = document.createElement('script');
    script.src = `https://api-maps.yandex.ru/2.1/?apikey=${YANDEX_MAPS_API_KEY}&lang=ru_RU&load=package.full`;
    script.async = true;
    script.defer = true; // Отложенная загрузка
    script.onload = () => {
      window.ymaps.ready(() => setIsLoaded(true));
    };
    script.onerror = () => {
      import('@/lib/logger').then(({ logger }) => {
        logger.error('Failed to load Yandex Maps API');
      });
    };
    document.head.appendChild(script);

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.destroy();
      }
    };
  }, []);

  // Инициализация карты и маркеров
  useEffect(() => {
    if (!isLoaded || !mapRef.current || !YANDEX_MAPS_API_KEY || markers.length === 0) {
      return;
    }

    window.ymaps.ready(() => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.destroy();
      }

      // Минимальный набор контролов для оптимизации производительности
      const map = new window.ymaps.Map(mapRef.current, {
        center: [centerCoords.lat, centerCoords.lng],
        zoom: centerCoords.zoom || 6,
        controls: ['zoomControl'], // Только зум для экономии ресурсов
        behaviors: ['default', 'scrollZoom'], // Отключаем лишние поведения
      });

      mapInstanceRef.current = map;

      // Очищаем старые маркеры и маршруты
      markersRef.current.forEach((marker) => {
        map.geoObjects.remove(marker);
      });
      markersRef.current = [];

      routesRef.current.forEach((route) => {
        map.geoObjects.remove(route);
      });
      routesRef.current = [];

      // Добавляем маркеры и маршруты
      markers.forEach(async (markerData) => {
        // Маркер отправления
        const fromMarker = new window.ymaps.Placemark(
          [markerData.fromCoords.lat, markerData.fromCoords.lng],
          {
            iconContent: 'A',
            hintContent: markerData.ride.from_city,
          },
          {
            preset: 'islands#greenCircleIcon',
          }
        );

        // Маркер назначения
        const toMarker = new window.ymaps.Placemark(
          [markerData.toCoords.lat, markerData.toCoords.lng],
          {
            iconContent: 'B',
            hintContent: markerData.ride.to_city,
            balloonContentHeader: `${markerData.ride.from_city} → ${markerData.ride.to_city}`,
            balloonContentBody: `${markerData.ride.price} ₽ • ${markerData.ride.seats_available} мест`,
            balloonContentFooter: `<button onclick="window.location.href='/ride/${markerData.ride.id}'" class="bg-primary text-white px-4 py-2 rounded">Подробнее</button>`,
          },
          {
            preset: 'islands#redCircleIcon',
          }
        );

        fromMarker.events.add('click', () => {
          navigate(`/ride/${markerData.ride.id}`);
        });

        toMarker.events.add('click', () => {
          navigate(`/ride/${markerData.ride.id}`);
        });

        map.geoObjects.add(fromMarker);
        map.geoObjects.add(toMarker);
        markersRef.current.push(fromMarker, toMarker);

        // Строим маршрут между точками
        try {
          const route = await buildRoute(
            markerData.fromCoords,
            markerData.toCoords
          );

          if (route && route.points.length > 1) {
            const routePoints = route.points.map(
              (point) => [point.lat, point.lng] as [number, number]
            );

            const polyline = new window.ymaps.Polyline(routePoints, {}, {
              strokeColor: '#0d9488',
              strokeWidth: 4,
              strokeOpacity: 0.7,
            });

            // Добавляем информацию о маршруте в подсказку
            const distance = formatDistance(route.distance);
            const duration = formatDuration(route.duration);
            polyline.properties.set('hintContent', `Маршрут: ${distance}, ${duration}`);

            map.geoObjects.add(polyline);
            routesRef.current.push(polyline);
          }
        } catch (error) {
          import('@/lib/logger').then(({ logger }) => {
            logger.error('Error building route', error);
          });
          // Если не удалось построить маршрут, рисуем прямую линию
          const polyline = new window.ymaps.Polyline(
            [
              [markerData.fromCoords.lat, markerData.fromCoords.lng],
              [markerData.toCoords.lat, markerData.toCoords.lng],
            ],
            {},
            {
              strokeColor: '#0d9488',
              strokeWidth: 3,
              strokeOpacity: 0.5,
              strokeStyle: '5 5', // Пунктирная линия
            }
          );
          map.geoObjects.add(polyline);
          routesRef.current.push(polyline);
        }
      });

      // Автоматически подстраиваем границы карты под все маркеры
      if (markers.length > 1) {
        const bounds = map.geoObjects.getBounds();
        if (bounds) {
          map.setBounds(bounds, {
            checkZoomRange: true,
            duration: 300,
          });
        }
      }
    });
  }, [isLoaded, markers, centerCoords, navigate]);

  if (!YANDEX_MAPS_API_KEY) {
    return (
      <div
        className={`bg-muted rounded-lg flex items-center justify-center border-2 border-dashed border-muted-foreground/20 ${className}`}
        style={{ height }}
      >
        <div className="text-center p-6 max-w-sm">
          <MapPin className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground font-medium mb-2">
            Карта недоступна
          </p>
          <p className="text-sm text-muted-foreground mb-4">
            Для отображения карты необходимо настроить Yandex Maps API ключ
          </p>
          <p className="text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg">
            Добавьте <code className="bg-background px-1 rounded">VITE_YANDEX_MAPS_API_KEY</code> в переменные окружения
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Получите ключ на{' '}
            <a
              href="https://developer.tech.yandex.ru/services/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary underline"
            >
              developer.tech.yandex.ru
            </a>
          </p>
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div
        className={`bg-muted rounded-lg flex items-center justify-center ${className}`}
        style={{ height }}
      >
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
          <p className="text-sm text-muted-foreground">Загрузка карты...</p>
        </div>
      </div>
    );
  }

  if (markers.length === 0) {
    return (
      <div
        className={`bg-muted rounded-lg flex items-center justify-center ${className}`}
        style={{ height }}
      >
        <div className="text-center p-6">
          <Car className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground font-medium mb-2">
            Нет поездок для отображения
          </p>
          <p className="text-sm text-muted-foreground">
            На карте будут показаны поездки с известными координатами
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`} style={{ height }}>
      <div
        ref={mapRef}
        style={{ width: '100%', height: '100%', borderRadius: '0.5rem' }}
      />
    </div>
  );
};
