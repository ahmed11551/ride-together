# 📋 Пошаговая инструкция настройки на Timeweb

## 🔧 Шаг 1: Настройка Backend (Node.js App)

### 1.1. Создание/открытие Backend приложения

1. Войдите в **Timeweb Cloud Dashboard**
2. Перейдите в раздел **"Облачные серверы"** или **"App Platform"**
3. Найдите или создайте **Node.js приложение** для backend

### 1.2. Добавление Environment Variables

**Где искать:**
- Откройте ваше **Backend приложение**
- Найдите раздел **"Переменные окружения"** или **"Environment Variables"**
- Или **"Настройки"** → **"Переменные окружения"**
- Или **"Конфигурация"** → **"Environment Variables"**

**Если не нашли:**
- Попробуйте **"Settings"** → **"Environment"**
- Или **"Configuration"** → **"Env Variables"**
- Или в настройках деплоя есть раздел **"Environment"**

**Добавьте переменные:**

```bash
DATABASE_URL=postgresql://gen_user:fn)un5%40K2oLrBJ@9d497bc2bf9dd679bd9834af.twc1.net:5432/default_db?sslmode=verify-full
JWT_SECRET=ваш-секретный-ключ-минимум-32-символа
ALLOWED_ORIGINS=https://ваш-frontend-домен.twc1.net
FRONTEND_URL=https://ваш-frontend-домен.twc1.net
PORT=3001
NODE_ENV=production
JWT_EXPIRES_IN=7d
```

### 1.3. Настройка деплоя Backend

**Где:**
- **"Деплой"** или **"Deploy"** → **"Настройки сборки"**
- Или **"Build Settings"**

**Установите:**
- **Build Command:** `cd server && npm install && npm run build` (если есть build) или просто `cd server && npm install`
- **Start Command:** `cd server && npm start` или `node server/index.js`
- **Working Directory:** `server` (если нужно)

---

## 🗄️ Шаг 2: Настройка PostgreSQL базы данных

### 2.1. Открытие SQL Editor

**Где искать:**
1. Перейдите в раздел **"Базы данных"** или **"Databases"**
2. Найдите вашу базу данных `default_db`
3. Откройте **"SQL Editor"** или **"Query Editor"**
4. Или найдите кнопку **"Выполнить SQL"** / **"Run SQL"**

**Если не нашли:**
- Попробуйте **"Управление БД"** → **"SQL"**
- Или **"Database Tools"** → **"SQL Editor"**
- Или через **phpPgAdmin** / **pgAdmin** (если доступен)

### 2.2. Применение схемы

1. Откройте файл `TIMEWEB_FULL_SCHEMA.sql` в проекте
2. Скопируйте **весь** содержимое файла
3. Вставьте в SQL Editor в Timeweb
4. Нажмите **"Выполнить"** или **"Run"**
5. Дождитесь завершения (должно быть сообщение об успехе)

---

## 🎨 Шаг 3: Настройка Frontend (Static Site)

### 3.1. Создание/открытие Frontend приложения

1. В разделе **"Статические сайты"** или **"Static Hosting"**
2. Или **"App Platform"** → создайте новое приложение

### 3.2. Настройка деплоя Frontend

**Где:**
- **"Настройки деплоя"** или **"Deploy Settings"**
- Или **"Build Configuration"**

**Установите:**
- **Framework:** `React` или `Vite` или `Static Site`
- **Build Command:** `npm run build`
- **Build Directory:** `dist`
- **Node.js Version:** `20` или `22`

### 3.3. Добавление Environment Variables для Frontend

**Где:**
- Так же как для backend - **"Переменные окружения"** или **"Environment Variables"**

**Добавьте:**
```bash
VITE_API_URL=https://ваш-backend-домен.twc1.net
VITE_WS_URL=wss://ваш-backend-домен.twc1.net
```

---

## 🔍 Если не можете найти опции

### Вариант 1: Через SSH

Если у вас есть доступ по SSH:

1. Подключитесь к серверу
2. Создайте файл `.env` в директории backend:
```bash
nano server/.env
```

3. Добавьте переменные:
```bash
DATABASE_URL=postgresql://gen_user:fn)un5%40K2oLrBJ@9d497bc2bf9dd679bd9834af.twc1.net:5432/default_db?sslmode=verify-full
JWT_SECRET=ваш-секретный-ключ
ALLOWED_ORIGINS=https://ваш-frontend-домен.twc1.net
FRONTEND_URL=https://ваш-frontend-домен.twc1.net
PORT=3001
NODE_ENV=production
```

4. Сохраните (Ctrl+O, Enter, Ctrl+X)

### Вариант 2: Через файл конфигурации

Если Timeweb использует файлы конфигурации:

1. Создайте файл `server/.env.production` в репозитории
2. Добавьте переменные (НЕ коммитьте в Git - добавьте в .gitignore)
3. Timeweb может автоматически подхватить `.env` файлы

### Вариант 3: Через Docker

Если используете Docker:

1. В `server/Dockerfile` добавьте:
```dockerfile
ENV DATABASE_URL=...
ENV JWT_SECRET=...
```

2. Или используйте `docker-compose.yml` с переменными

---

## 📞 Что делать, если не нашли нужные опции

1. **Проверьте документацию Timeweb:**
   - Поищите "Environment Variables" в документации
   - Или "Переменные окружения"

2. **Обратитесь в поддержку Timeweb:**
   - Спросите, где настраивать переменные окружения для Node.js приложений
   - Или как подключиться к PostgreSQL базе данных

3. **Альтернатива - через код:**
   - Можно хардкодить переменные в `server/index.ts` (НЕ рекомендуется для production)
   - Или использовать файл `.env` локально

---

## ✅ Проверка

После настройки:

1. **Backend:**
   - Проверьте логи деплоя - не должно быть ошибок подключения к БД
   - Откройте `https://ваш-backend-домен.twc1.net/health` - должно вернуть `{"status":"ok"}`

2. **Frontend:**
   - Откройте сайт в браузере
   - Проверьте консоль (F12) - не должно быть ошибок
   - Попробуйте зарегистрироваться/войти

3. **База данных:**
   - В SQL Editor выполните: `SELECT * FROM users LIMIT 1;`
   - Должно вернуть пустой результат (таблица существует, но пустая)
