# 🛠️ Timeweb Cloud CLI (twc) - Использование для проекта

## 🎯 Что это?

**Timeweb Cloud CLI (`twc`)** — это утилита командной строки для управления сервисами Timeweb Cloud. Она предоставляет удобный интерфейс для работы с API через терминал.

**Источник:** [Официальная документация](https://timeweb.cloud/docs/twc-cli/twc-cli-start)

---

## ✅ Преимущества CLI над прямым API

1. **Проще использовать** — команды вместо curl запросов
2. **Автодополнение** — встроенная справка и подсказки
3. **Удобнее в скриптах** — понятный синтаксис
4. **Меньше ошибок** — валидация параметров
5. **Лучшая интеграция** — работает с другими CLI утилитами

---

## 📦 Установка

### Способ 1: Через pip (рекомендуется)

```bash
pip install twc-cli
```

### Способ 2: Из файла .tar.gz

```bash
# Скачать с https://timeweb.cloud/downloads
pip install twc-cli-*.tar.gz
```

### Обновление

```bash
pip install --upgrade twc-cli
```

---

## 🚀 Начало работы

### 1. Получить токен API

1. Войдите в панель управления Timeweb Cloud
2. Перейдите в раздел **"Токены API"**
3. Создайте новый токен с любым сроком действия

### 2. Настроить twc

```bash
twc auth
```

Введите токен, и `twc` сохранит его в конфигурационном файле.

---

## 📚 Справка

### Общая справка

```bash
twc --help
```

### Справка по командам

```bash
# Справка по серверам
twc server --help

# Справка по базам данных
twc database --help

# И т.д.
```

---

## 💡 Полезные команды для Ride Together

### Управление базами данных

```bash
# Список всех баз данных
twc database list

# Получить информацию о БД
twc database get <db_id>

# Создать новую БД
twc database create \
  --preset-id 443 \
  --type postgresql \
  --name ride-together-db

# Обновить БД
twc database update <db_id> --name new-name

# Удалить БД
twc database delete <db_id>

# Создать бэкап
twc database backup create <db_id>

# Список бэкапов
twc database backup list <db_id>

# Восстановить из бэкапа
twc database backup restore <db_id> --backup-id <backup_id>
```

### Управление серверами

```bash
# Список серверов
twc server list

# Получить информацию о сервере
twc server get <server_id>

# Создать сервер
twc server create \
  --os-id 123 \
  --preset-id 456 \
  --name ride-backend

# Обновить сервер
twc server update <server_id> --name new-name

# Удалить сервер
twc server delete <server_id>
```

### Управление проектами

```bash
# Список проектов
twc project list

# Создать проект
twc project create --name ride-together

# Получить информацию о проекте
twc project get <project_id>
```

### Аккаунт и финансы

```bash
# Получить информацию о финансах
twc account finances

# Получить стоимость сервисов
twc account services cost
```

---

## 🔧 Автоматизация для Ride Together

### Скрипт проверки инфраструктуры

```bash
#!/bin/bash
# scripts/check-infrastructure.sh

echo "🔍 Checking infrastructure..."

# Проверить статус БД
echo "📊 Database status:"
twc database get $TIMEWEB_DB_ID

# Проверить статус серверов
echo "🖥️  Servers status:"
twc server list

# Проверить баланс
echo "💰 Balance:"
twc account finances

echo "✅ Check complete"
```

### Скрипт автоматического бэкапа

```bash
#!/bin/bash
# scripts/backup-database.sh

DB_ID=${TIMEWEB_DB_ID}
BACKUP_NAME="backup-$(date +%Y%m%d-%H%M%S)"

echo "💾 Creating backup: $BACKUP_NAME"

# Создать бэкап
BACKUP_ID=$(twc database backup create $DB_ID --name $BACKUP_NAME | jq -r '.backup.id')

if [ -n "$BACKUP_ID" ]; then
  echo "✅ Backup created: $BACKUP_ID"
  
  # Отправить уведомление (если нужно)
  # ...
else
  echo "❌ Failed to create backup"
  exit 1
fi
```

### Скрипт деплоя

```bash
#!/bin/bash
# scripts/deploy.sh

set -e

echo "🚀 Starting deployment..."

# 1. Проверить, что БД запущена
echo "📊 Checking database..."
DB_STATUS=$(twc database get $TIMEWEB_DB_ID | jq -r '.db.status')

if [ "$DB_STATUS" != "running" ]; then
  echo "❌ Database is not running (status: $DB_STATUS)"
  exit 1
fi

echo "✅ Database is running"

# 2. Создать бэкап перед деплоем
echo "💾 Creating backup..."
twc database backup create $TIMEWEB_DB_ID

# 3. Проверить баланс
echo "💰 Checking balance..."
BALANCE=$(twc account finances | jq -r '.finances.balance')
echo "Balance: $BALANCE ₽"

# 4. Деплой backend (если нужно)
echo "🔧 Deploying backend..."
# ... ваши команды деплоя

# 5. Деплой frontend (если нужно)
echo "🎨 Deploying frontend..."
# ... ваши команды деплоя

echo "✅ Deployment complete"
```

### Скрипт мониторинга

```bash
#!/bin/bash
# scripts/monitor.sh

echo "📊 Monitoring infrastructure..."

# Статус БД
DB_STATUS=$(twc database get $TIMEWEB_DB_ID | jq -r '.db.status')
echo "Database: $DB_STATUS"

# Статус серверов
SERVER_COUNT=$(twc server list | jq '.servers | length')
echo "Servers: $SERVER_COUNT"

# Стоимость
COST=$(twc account services cost | jq -r '.costs | map(.price) | add')
echo "Monthly cost: $COST ₽"

# Алерты
if [ "$DB_STATUS" != "running" ]; then
  echo "⚠️  WARNING: Database is not running!"
  # Отправить уведомление
fi

if (( $(echo "$COST > 1000" | bc -l) )); then
  echo "⚠️  WARNING: Monthly cost exceeds 1000₽!"
  # Отправить уведомление
fi
```

---

## 🔄 CI/CD интеграция

### GitHub Actions пример

```yaml
# .github/workflows/deploy.yml
name: Deploy to Timeweb

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install twc CLI
        run: |
          pip install twc-cli
      
      - name: Configure twc
        run: |
          echo "${{ secrets.TIMEWEB_TOKEN }}" | twc auth --token-stdin
      
      - name: Check database status
        run: |
          twc database get ${{ secrets.TIMEWEB_DB_ID }}
      
      - name: Create backup
        run: |
          twc database backup create ${{ secrets.TIMEWEB_DB_ID }}
      
      - name: Deploy backend
        run: |
          # Ваши команды деплоя backend
      
      - name: Deploy frontend
        run: |
          # Ваши команды деплоя frontend
```

### GitLab CI пример

```yaml
# .gitlab-ci.yml
deploy:
  image: python:3.11
  before_script:
    - pip install twc-cli
    - echo "$TIMEWEB_TOKEN" | twc auth --token-stdin
  script:
    - twc database get $TIMEWEB_DB_ID
    - twc database backup create $TIMEWEB_DB_ID
    # ... деплой
```

---

## 📋 Полезные команды

### Экспорт в JSON

```bash
# Получить данные в JSON формате
twc database get <db_id> --output json | jq '.'

# Список серверов в JSON
twc server list --output json | jq '.servers[] | {id, name, status}'
```

### Фильтрация и поиск

```bash
# Найти БД по имени
twc database list | jq '.dbs[] | select(.name | contains("ride"))'

# Найти серверы в определенном статусе
twc server list | jq '.servers[] | select(.status == "running")'
```

### Параллельные операции

```bash
# Создать несколько бэкапов параллельно
for db_id in $DB_ID_1 $DB_ID_2 $DB_ID_3; do
  twc database backup create $db_id &
done
wait
```

---

## 🎯 Сравнение: API vs CLI

| Задача | API (curl) | CLI (twc) |
|--------|------------|-----------|
| Получить список БД | `curl -H "Authorization: Bearer $TOKEN" https://api.timeweb.cloud/api/v1/databases` | `twc database list` |
| Создать бэкап | `curl -X POST -H "Authorization: Bearer $TOKEN" https://api.timeweb.cloud/api/v1/databases/$ID/backups` | `twc database backup create $ID` |
| Проверить баланс | `curl -H "Authorization: Bearer $TOKEN" https://api.timeweb.cloud/api/v1/account/finances` | `twc account finances` |

**CLI проще и понятнее!** ✅

---

## 🔐 Безопасность

### Хранение токена

`twc` сохраняет токен в конфигурационном файле:
- Linux/macOS: `~/.config/twc/config.yaml`
- Windows: `%APPDATA%\twc\config.yaml`

### Использование в скриптах

**Вариант 1:** Переменная окружения
```bash
export TIMEWEB_TOKEN="your-token"
twc auth --token-stdin <<< "$TIMEWEB_TOKEN"
```

**Вариант 2:** Секреты в CI/CD
```yaml
# GitHub Actions
- name: Configure twc
  run: echo "${{ secrets.TIMEWEB_TOKEN }}" | twc auth --token-stdin
```

**Вариант 3:** Интерактивная настройка
```bash
twc auth
# Ввести токен вручную
```

---

## 📚 Документация и ресурсы

- **Официальная документация:** https://timeweb.cloud/docs/twc-cli/twc-cli-start
- **GitHub с примерами:** https://github.com/timeweb-cloud/twc-cli (указано в документации)
- **Справка:** `twc --help`

---

## 💡 Рекомендации для Ride Together

### Что стоит использовать CLI:

1. ✅ **Регулярные операции** (бэкапы, проверки)
2. ✅ **Мониторинг** (статус, баланс)
3. ✅ **Автоматизация** (скрипты деплоя)
4. ✅ **CI/CD** (интеграция в пайплайны)

### Что можно делать вручную:

- Первоначальная настройка
- Редкие операции
- Разовая настройка

---

## 🚀 Быстрый старт

```bash
# 1. Установить
pip install twc-cli

# 2. Настроить
twc auth
# Ввести токен из панели управления

# 3. Проверить
twc database list
twc server list
twc account finances

# 4. Начать использовать!
```

---

## ✅ Преимущества для проекта

1. **Проще писать скрипты** — понятные команды
2. **Меньше ошибок** — валидация параметров
3. **Удобнее отладка** — читаемый вывод
4. **Лучшая интеграция** — работает с другими утилитами
5. **Автоматизация** — легко интегрируется в CI/CD

**CLI (`twc`) + API (OpenAPI) = Полная автоматизация инфраструктуры!** 🎉

