# ✅ План действий - что делать дальше

## 🎯 Текущий статус

✅ VPS создан на REG.RU  
✅ IP-адреса получены  
✅ Скрипты автоматизации готовы  
✅ Документация подготовлена

---

## 📋 ШАГИ (выполняйте по порядку):

### ⚡ ШАГ 1: Получите пароль root

**Если не можете найти пароль, см. подробную инструкцию:** `REG_RU_GET_PASSWORD.md`

**Быстрая проверка:**

1. **Проверьте email** - REG.RU отправляет пароль при создании VPS
2. Откройте панель: **https://cloud.reg.ru/panel/servers**
3. Найдите сервер **`194.67.124.123`**
4. Проверьте разделы:
   - **"Доступ"** / **"Access"**
   - **"Пароли"** / **"Passwords"**
   - **"Управление доступом"**
   - **"Информация"** - может быть кнопка "Показать пароль" 👁️
5. Если нет - сбросьте пароль через раздел **"Управление"** → **"Сбросить пароль"**

**⏱️ Время:** 2-5 минут

---

### ⚡ ШАГ 2: Автоматическая настройка VPS

Откройте терминал и выполните:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together
./scripts/quick-setup-regru.sh 194.67.124.123 root
```

**Когда скрипт попросит пароль** - вставьте пароль root из панели REG.RU.

**Что сделает скрипт:**
- ✅ Установит Node.js 20.x
- ✅ Установит PostgreSQL
- ✅ Установит Nginx
- ✅ Установит PM2
- ✅ Установит Certbot
- ✅ Настроит Firewall
- ✅ Создаст базу данных `ride_together`
- ✅ Создаст пользователя БД и сгенерирует пароль

**⏱️ Время:** 3-5 минут

**📝 Важно:** Скрипт сохранит пароль БД в `/tmp/regru-db-info.txt` на сервере - вам понадобится эта информация!

---

### ⚡ ШАГ 3: Копирование проекта на сервер

На вашем локальном компьютере:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Создайте архив проекта (исключая ненужные файлы)
tar -czf ride-together.tar.gz \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='dist' \
  --exclude='*.log' \
  --exclude='.env*' \
  .

# Скопируйте на сервер (введет пароль root)
scp ride-together.tar.gz root@194.67.124.123:/var/www/
```

**⏱️ Время:** 1-2 минуты (зависит от размера проекта)

---

### ⚡ ШАГ 4: Распаковка проекта на сервере

Подключитесь к серверу:

```bash
ssh root@194.67.124.123
```

На сервере:

```bash
cd /var/www
tar -xzf ride-together.tar.gz -C ride-together
cd ride-together
```

**⏱️ Время:** 1 минута

---

### ⚡ ШАГ 5: Настройка Backend

На сервере:

```bash
cd /var/www/ride-together/server

# Скопируйте пример конфигурации
cp env.regru.example .env.production

# Получите информацию о БД (пароль!)
cat /tmp/regru-db-info.txt

# Откройте .env.production для редактирования
nano .env.production
```

**В `.env.production` укажите:**

```env
# Из /tmp/regru-db-info.txt скопируйте DATABASE_URL
DATABASE_URL=postgresql://ride_user:ПАРОЛЬ_ИЗ_СКРИПТА@localhost:5432/ride_together

# Сгенерируйте JWT_SECRET
JWT_SECRET=ВАШ_СЛОЖНЫЙ_СЕКРЕТ_32_СИМВОЛА

# Временно используйте публичный IP
ALLOWED_ORIGINS=http://194.67.124.123
FRONTEND_URL=http://194.67.124.123

# Остальное можно оставить по умолчанию
PORT=3001
NODE_ENV=production
HOST=0.0.0.0
```

**Сохраните:** `Ctrl+O`, `Enter`, `Ctrl+X`

**Установите зависимости и соберите:**

```bash
npm install --production
npm run build
```

**Импортируйте схему базы данных:**

```bash
sudo -u postgres psql ride_together < ../TIMEWEB_FULL_SCHEMA.sql
```

**Запустите через PM2:**

```bash
pm2 start dist/index.js --name ride-backend
pm2 save
pm2 startup
# Скопируйте команду из вывода и выполните её
```

**Проверьте работу:**

```bash
pm2 logs ride-backend
# Должны быть логи без ошибок
# Нажмите Ctrl+C для выхода
```

**⏱️ Время:** 5-7 минут

---

### ⚡ ШАГ 6: Настройка Frontend

На сервере:

```bash
cd /var/www/ride-together

# Создайте .env.production
cat > .env.production <<EOF
VITE_API_URL=http://194.67.124.123/api
VITE_WS_URL=ws://194.67.124.123
EOF

# Установите зависимости
npm install

# Соберите проект
npm run build

# Скопируйте в Nginx директорию
cp -r dist/* /var/www/html/
chown -R www-data:www-data /var/www/html
```

**⏱️ Время:** 3-5 минут (зависит от размера проекта)

---

### ⚡ ШАГ 7: Настройка Nginx

На сервере создайте конфигурацию Nginx:

```bash
cat > /etc/nginx/sites-available/ride-together <<'EOF'
server {
    listen 80;
    server_name 194.67.124.123;
    
    root /var/www/html;
    index index.html;
    
    # Frontend
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Backend API
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # WebSocket
    location /socket.io {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
EOF

# Активируйте конфигурацию
ln -sf /etc/nginx/sites-available/ride-together /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Проверьте конфигурацию
nginx -t

# Перезагрузите Nginx
systemctl reload nginx
```

**⏱️ Время:** 2 минуты

---

## 🎉 Готово! Проверьте работу

Откройте в браузере:

- **Frontend:** http://194.67.124.123
- **API Health Check:** http://194.67.124.123/api/health

---

## 🔧 Полезные команды для проверки

```bash
# Логи Backend
pm2 logs ride-backend

# Статус сервисов
systemctl status nginx
systemctl status postgresql
pm2 status

# Проверка портов
netstat -tlnp | grep -E ':(80|443|3001|5432)'
```

---

## 🚨 Если что-то не работает

### Backend не запускается:
```bash
pm2 logs ride-backend
# Проверьте ошибки в логах
```

### База данных недоступна:
```bash
sudo -u postgres psql ride_together
# Проверьте подключение
```

### Nginx не работает:
```bash
nginx -t
systemctl status nginx
```

### Файлы не загружаются:
```bash
ls -la /var/www/html/
chown -R www-data:www-data /var/www/html
```

---

## 📚 Дополнительные материалы

- **Полная инструкция:** `NEXT_STEPS.md`
- **Быстрый старт:** `QUICK_START_REG_RU.md`
- **Сетевая конфигурация:** `REG_RU_NETWORK_INFO.md`

---

## ⏱️ Общее время настройки: ~20-30 минут

**Начните с ШАГА 1 - получите пароль root!** 🔑
