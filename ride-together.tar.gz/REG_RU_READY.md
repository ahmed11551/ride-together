# ✅ Готово к миграции на REG.RU!

## 🎉 Все подготовлено для автоматической миграции!

---

## 📋 Что уже готово:

✅ **Токен сохранен** - `.env.regru.token` (безопасно, в .gitignore)  
✅ **Скрипты автоматизации** - готовы к использованию  
✅ **Конфигурационные файлы** - для REG.RU  
✅ **Документация** - полные инструкции  

---

## 🚀 Что делать СЕЙЧАС:

### 1. Создайте VPS на REG.RU (5 минут)

1. Зайдите: https://reg.ru
2. **Облачный VPS** → **Заказать**
3. Выберите:
   - **ОС:** Ubuntu 22.04 LTS
   - **Конфигурация:** 2 vCPU, 2GB RAM, 20GB SSD (минимум)
   - **Локация:** Россия
4. **Оплатите** (~350-500₽/месяц)
5. **Запишите IP адрес**

---

### 2. Запустите автоматическую настройку

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Запустить автоматическую настройку
./scripts/auto-setup-regru.sh YOUR_VPS_IP root
```

**Скрипт спросит у вас:**
- Создать БД автоматически? → **y**
- URL репозитория → **ваш GitHub/GitLab URL**
- Домен API → например: **api.your-domain.ru**
- Домен Frontend → например: **your-domain.ru**  
- Получить SSL? → **y** (если домен настроен)

**Время выполнения: ~15-20 минут**

---

### 3. Импорт данных (если есть бэкап)

Если нужно импортировать данные с Timeweb:

```bash
# Создать бэкап с Timeweb
twc database backup create $TIMEWEB_DB_ID

# Или через pg_dump
pg_dump -h timeweb-host -U user -d db > backup.sql

# Импортировать на REG.RU
scp backup.sql root@YOUR_VPS_IP:/tmp/
ssh root@YOUR_VPS_IP "psql -U ride_user -d ride_together < /tmp/backup.sql"
```

Или применить схему:
```bash
scp TIMEWEB_FULL_SCHEMA.sql root@YOUR_VPS_IP:/tmp/
ssh root@YOUR_VPS_IP "psql -U ride_user -d ride_together < /tmp/TIMEWEB_FULL_SCHEMA.sql"
```

---

## ✅ Что автоматически настроится:

### На VPS установится:
- ✅ Node.js 20.x
- ✅ PostgreSQL
- ✅ Nginx
- ✅ PM2 (менеджер процессов)
- ✅ Certbot (для SSL)
- ✅ Firewall (базовая настройка)

### Будет создано:
- ✅ База данных PostgreSQL
- ✅ Пользователь БД с правами
- ✅ Директории для приложения

### Будет настроено:
- ✅ Backend:
  - Клонирован/обновлен код
  - Установлены зависимости
  - Создан .env.production
  - Собран проект
  - Запущен через PM2

- ✅ Frontend:
  - Собран проект
  - Размещен в /var/www/html
  - Настроена маршрутизация

- ✅ Nginx:
  - Reverse proxy для API
  - Статика для Frontend
  - WebSocket прокси
  - SSL сертификат (если есть домен)

---

## 🔍 Проверка после установки:

```bash
# Health check Backend
ssh root@YOUR_VPS_IP "curl http://localhost:3001/health"

# Статус PM2
ssh root@YOUR_VPS_IP "pm2 status"

# Логи Backend
ssh root@YOUR_VPS_IP "pm2 logs ride-backend"

# Статус Nginx
ssh root@YOUR_VPS_IP "sudo systemctl status nginx"

# Проверка БД
ssh root@YOUR_VPS_IP "sudo -u postgres psql -d ride_together -c 'SELECT COUNT(*) FROM users;'"
```

---

## 📚 Документация:

### Для быстрого старта:
- **`START_HERE_REG_RU.md`** - начните здесь ⭐
- **`REG_RU_QUICK_START.md`** - быстрая инструкция

### Для детального понимания:
- **`REG_RU_MIGRATION_PLAN.md`** - полный план миграции
- **`REG_RU_FULL_AUTOMATION.md`** - детали автоматизации

### Конфигурация:
- **`server/env.regru.example`** - переменные Backend
- **`env.regru.example`** - переменные Frontend
- **`nginx-regru.conf.example`** - конфигурация Nginx

### Скрипты:
- **`scripts/auto-setup-regru.sh`** - автоматическая настройка ⭐
- **`scripts/deploy-regru.sh`** - деплой обновлений
- **`scripts/setup-regru-vps.sh`** - настройка VPS (альтернатива)

---

## 🎯 Порядок действий:

```
1. Создать VPS на REG.RU ─────────────────┐
   (вы делаете, требует оплаты)           │
                                           │
2. Запустить скрипт автоматизации ────────┤
   ./scripts/auto-setup-regru.sh          │ → Всё настроится автоматически!
   (я делаю)                               │
                                           │
3. Импорт данных (если нужно) ────────────┘
   (опционально)
```

---

## ⚠️ Важные замечания:

### Что я НЕ могу сделать:
- ❌ Создать платные ресурсы (VPS) - требует оплаты
- ❌ Оплатить услуги
- ❌ Зарегистрировать домен

### Что я СДЕЛАЮ автоматически:
- ✅ Установлю все пакеты
- ✅ Настрою базу данных
- ✅ Разверну приложение
- ✅ Настрою веб-сервер
- ✅ Настрою SSL
- ✅ Запущу всё в production

---

## 💡 Советы:

1. **SSH ключ** - лучше настроить SSH ключ вместо пароля:
   ```bash
   ssh-keygen -t rsa -b 4096
   ssh-copy-id root@YOUR_VPS_IP
   ```

2. **Домен** - если есть домен, настройте DNS:
   - A-запись `@` → IP VPS
   - A-запись `api` → IP VPS (или используйте `/api`)

3. **Мониторинг** - после миграции настройте мониторинг:
   ```bash
   # Добавить в cron для мониторинга
   */30 * * * * pm2 status && curl http://localhost:3001/health
   ```

---

## 🎉 Готово!

**Создайте VPS на REG.RU, затем запустите:**

```bash
./scripts/auto-setup-regru.sh YOUR_VPS_IP root
```

**И всё настроится автоматически!** 🚀

---

## 📞 Если что-то не работает:

1. Проверьте SSH подключение: `ssh root@YOUR_VPS_IP`
2. Проверьте логи: `ssh root@YOUR_VPS_IP "pm2 logs ride-backend"`
3. Проверьте Nginx: `ssh root@YOUR_VPS_IP "sudo nginx -t"`
4. Смотрите документацию в `REG_RU_MIGRATION_PLAN.md`

---

**Удачи с миграцией!** 🎯

