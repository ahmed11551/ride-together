# 🚀 НАЧНИТЕ ЗДЕСЬ - Миграция на REG.RU

## ✅ Токен получен и сохранен!

Ваш API токен REG.RU сохранен и готов к использованию.

---

## 🎯 Что нужно сделать ВАМ:

### 1. Создать VPS на REG.RU (5 минут, требует оплаты ~350-500₽/месяц)

1. Зайдите на https://reg.ru
2. Перейдите: **Облачный VPS** → **Заказать**
3. Выберите:
   - **ОС:** Ubuntu 22.04 LTS ⭐
   - **Конфигурация:** 
     - Минимум: 2 vCPU, 2GB RAM, 20GB SSD
     - Оптимально: 2 vCPU, 4GB RAM, 40GB SSD
4. **Оплатите** (~350-500₽/месяц)
5. **Запишите IP адрес** сервера

---

## 🤖 Что настрою Я автоматически:

После создания VPS запустите **ОДИН** скрипт:

```bash
./scripts/auto-setup-regru.sh YOUR_VPS_IP root
```

### Автоматически установится и настроится:

✅ Node.js 20.x  
✅ PostgreSQL  
✅ Nginx  
✅ PM2  
✅ Certbot (SSL)  
✅ База данных  
✅ Backend (установка, сборка, запуск)  
✅ Frontend (сборка, развертывание)  
✅ Nginx конфигурация  
✅ SSL сертификат  

**Время автоматической настройки: ~15-20 минут**

---

## 📋 Быстрая инструкция:

### Шаг 1: Создайте VPS
- REG.RU → Облачный VPS → Заказать
- Ubuntu 22.04, 2 vCPU, 2GB RAM
- Оплатите и запишите IP

### Шаг 2: Запустите автоматизацию

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together
./scripts/auto-setup-regru.sh YOUR_VPS_IP root
```

Скрипт спросит:
- Создать БД? → **y**
- URL репозитория → ваш GitHub/GitLab URL
- Домен API → например: **api.your-domain.ru**
- Домен Frontend → например: **your-domain.ru**
- Получить SSL? → **y** (если есть домен)

### Шаг 3: Импорт данных (если нужно)

Если есть бэкап с Timeweb:

```bash
# Экспорт
twc database backup create $TIMEWEB_DB_ID

# Импорт
scp backup.sql root@YOUR_VPS_IP:/tmp/
ssh root@YOUR_VPS_IP "psql -U ride_user -d ride_together < /tmp/backup.sql"
```

---

## ✅ Готово!

После запуска скрипта приложение будет полностью настроено и работать!

Проверка:
```bash
ssh root@YOUR_VPS_IP "curl http://localhost:3001/health"
ssh root@YOUR_VPS_IP "pm2 status"
```

---

## 📚 Полная документация:

- `REG_RU_FULL_AUTOMATION.md` - Полная автоматизация
- `REG_RU_MIGRATION_PLAN.md` - Детальный план
- `REG_RU_QUICK_START.md` - Быстрый старт

---

**🎉 Создайте VPS, запустите скрипт - и всё заработает автоматически!**

