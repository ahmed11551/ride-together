# 🚀 Быстрый старт на REG.RU VPS

## ✅ Ваш VPS готов!

**IP-адрес:** `194.67.124.123`

---

## 📝 Шаг 1: Получите доступ к серверу

### Вариант A: Получить пароль root

1. Откройте панель REG.RU: https://cloud.reg.ru/panel/servers
2. Найдите сервер с IP `194.67.124.123`
3. Откройте раздел **"Доступ"** или **"Пароли"**
4. Скопируйте пароль root (или сбросьте, если нужно)

### Вариант B: Добавить SSH ключ

Если у вас есть SSH ключ:

```bash
# Покажите ваш публичный ключ
cat ~/.ssh/id_ed25519.pub

# Скопируйте вывод и добавьте в панели REG.RU в настройках сервера
```

Если нет SSH ключа, создайте:

```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
cat ~/.ssh/id_ed25519.pub
```

---

## 🎯 Шаг 2: Первоначальная настройка VPS

Запустите автоматический скрипт (он установит всё необходимое):

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together
./scripts/quick-setup-regru.sh 194.67.124.123 root
```

**Скрипт установит:**
- ✅ Node.js 20.x
- ✅ PostgreSQL
- ✅ Nginx
- ✅ PM2
- ✅ Certbot
- ✅ Создаст базу данных

**Скрипт запросит пароль** - введите пароль root, который получили в панели REG.RU.

---

## 🔧 Шаг 3: Копирование проекта на сервер

После первоначальной настройки, скопируйте проект:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Создайте архив проекта
tar -czf ride-together.tar.gz \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='dist' \
  --exclude='*.log' \
  --exclude='.env*' \
  .

# Скопируйте на сервер
scp ride-together.tar.gz root@194.67.124.123:/var/www/

# Подключитесь к серверу
ssh root@194.67.124.123

# На сервере распакуйте
cd /var/www
tar -xzf ride-together.tar.gz -C ride-together
cd ride-together
```

---

## ⚙️ Шаг 4: Настройка Backend

На сервере выполните:

```bash
cd /var/www/ride-together/server

# Скопируйте пример конфигурации
cp env.regru.example .env.production

# Отредактируйте .env.production
nano .env.production
```

**Укажите в `.env.production`:**
- `DATABASE_URL` - из файла `/tmp/regru-db-info.txt` (создан скриптом)
- `JWT_SECRET` - сгенерируйте: `openssl rand -base64 32`
- `ALLOWED_ORIGINS` - пока можно `http://194.67.124.123`
- `FRONTEND_URL` - пока `http://194.67.124.123`

**Установите зависимости и соберите:**

```bash
npm install --production
npm run build
```

**Импортируйте схему базы данных:**

```bash
# Сначала получите пароль БД из /tmp/regru-db-info.txt
cat /tmp/regru-db-info.txt

# Импортируйте схему
sudo -u postgres psql ride_together < /var/www/ride-together/TIMEWEB_FULL_SCHEMA.sql
```

**Запустите через PM2:**

```bash
pm2 start dist/index.js --name ride-backend
pm2 save
pm2 startup
```

---

## 🎨 Шаг 5: Настройка Frontend

На сервере:

```bash
cd /var/www/ride-together

# Создайте .env.production
cat > .env.production <<EOF
VITE_API_URL=http://194.67.124.123/api
VITE_WS_URL=ws://194.67.124.123
EOF

# Установите зависимости и соберите
npm install
npm run build

# Скопируйте в Nginx директорию
cp -r dist/* /var/www/html/
chown -R www-data:www-data /var/www/html
```

---

## 🌐 Шаг 6: Настройка Nginx

Создайте конфигурацию Nginx:

```bash
cat > /etc/nginx/sites-available/ride-together <<'EOF'
server {
    listen 80;
    server_name 194.67.124.123;
    
    root /var/www/html;
    index index.html;
    
    # Frontend
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Backend API
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # WebSocket
    location /socket.io {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
EOF

# Активируйте конфигурацию
ln -sf /etc/nginx/sites-available/ride-together /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

---

## ✅ Шаг 7: Проверка

Откройте в браузере:
- Frontend: http://194.67.124.123
- API Health: http://194.67.124.123/api/health

Проверьте логи:
```bash
pm2 logs ride-backend
```

---

## 🔒 Шаг 8: SSL сертификат (опционально)

Если у вас есть домен:

```bash
certbot --nginx -d your-domain.ru -d www.your-domain.ru
```

---

## 📚 Полезные команды

```bash
# Логи Backend
pm2 logs ride-backend

# Перезапуск Backend
pm2 restart ride-backend

# Статус сервисов
systemctl status nginx
systemctl status postgresql

# Подключение к БД
sudo -u postgres psql ride_together
```

---

## 🆘 Помощь

Если что-то не работает:
1. Проверьте логи: `pm2 logs ride-backend`
2. Проверьте Nginx: `sudo nginx -t && sudo systemctl status nginx`
3. Проверьте PostgreSQL: `sudo systemctl status postgresql`
4. Посмотрите полную инструкцию: `cat SETUP_REG_RU_VPS.md`

---

**Удачи! 🚀**

