# ✅ Сервер настроен! Следующие шаги

## 🎉 Установлено и готово:

- ✅ Node.js 20.19.6
- ✅ PostgreSQL 16
- ✅ Nginx
- ✅ PM2
- ✅ Certbot
- ✅ Firewall
- ✅ База данных `ride_together` создана

---

## 🔐 Важная информация (СОХРАНИТЕ!)

**База данных:**
- Имя: `ride_together`
- Пользователь: `ride_user`
- Пароль: `WYRbRRAxljRjg4yT97ejxDaXi`
- DATABASE_URL: `postgresql://ride_user:WYRbRRAxljRjg4yT97ejxDaXi@localhost:5432/ride_together`

**Сеть:**
- Публичный IP: `194.67.124.123`
- Приватный IP: `192.168.0.107`

---

## 📋 Шаг 1: Копирование проекта на сервер

На вашем Mac выполните:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Создайте архив проекта
tar -czf ride-together.tar.gz \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='dist' \
  --exclude='*.log' \
  --exclude='.env*' \
  .

# Скопируйте на сервер
scp ride-together.tar.gz root@194.67.124.123:/var/www/
```

---

## 📋 Шаг 2: Распаковка проекта на сервере

Подключитесь к серверу:

```bash
ssh root@194.67.124.123
```

На сервере:

```bash
cd /var/www
tar -xzf ride-together.tar.gz -C ride-together
cd ride-together
```

---

## 📋 Шаг 3: Настройка Backend

На сервере:

```bash
cd /var/www/ride-together/server

# Скопируйте конфигурацию
cp env.regru.example .env.production

# Откройте для редактирования
nano .env.production
```

**В `.env.production` укажите:**

```env
DATABASE_URL=postgresql://ride_user:WYRbRRAxljRjg4yT97ejxDaXi@localhost:5432/ride_together

JWT_SECRET=СГЕНЕРИРУЙТЕ_СВОЙ_СЕКРЕТ_32_СИМВОЛА

PORT=3001
NODE_ENV=production
HOST=0.0.0.0

ALLOWED_ORIGINS=http://194.67.124.123
FRONTEND_URL=http://194.67.124.123
```

**Сгенерируйте JWT_SECRET:**
```bash
openssl rand -base64 32
```

**Сохраните файл:** `Ctrl+O`, `Enter`, `Ctrl+X`

**Установите зависимости и соберите:**
```bash
npm install --production
npm run build
```

**Импортируйте схему БД:**
```bash
sudo -u postgres psql ride_together < ../TIMEWEB_FULL_SCHEMA.sql
```

**Запустите через PM2:**
```bash
pm2 start dist/index.js --name ride-backend
pm2 save
pm2 startup
# Выполните команду из вывода pm2 startup
```

---

## 📋 Шаг 4: Настройка Frontend

На сервере:

```bash
cd /var/www/ride-together

# Создайте .env.production
cat > .env.production <<EOF
VITE_API_URL=http://194.67.124.123/api
VITE_WS_URL=ws://194.67.124.123
EOF

# Установите зависимости и соберите
npm install
npm run build

# Скопируйте в Nginx
cp -r dist/* /var/www/html/
chown -R www-data:www-data /var/www/html
```

---

## 📋 Шаг 5: Настройка Nginx

На сервере:

```bash
cat > /etc/nginx/sites-available/ride-together <<'EOF'
server {
    listen 80;
    server_name 194.67.124.123;
    
    root /var/www/html;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /socket.io {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
EOF

# Активируйте конфигурацию
ln -sf /etc/nginx/sites-available/ride-together /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

---

## ✅ Проверка

Откройте в браузере:
- Frontend: http://194.67.124.123
- API: http://194.67.124.123/api/health

---

## 🔧 Полезные команды

```bash
# Логи Backend
pm2 logs ride-backend

# Статус сервисов
pm2 status
systemctl status nginx
systemctl status postgresql

# Перезапуск Backend
pm2 restart ride-backend
```

---

**Начните с копирования проекта на сервер!** 🚀

