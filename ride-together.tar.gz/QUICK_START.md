# 🚀 Быстрый запуск Ride Together

## Минимальные требования для запуска

### 1. Переменные окружения (ОБЯЗАТЕЛЬНО)

Создайте `.env` в корне проекта:

```env
# Backend API - ОБЯЗАТЕЛЬНО
VITE_API_URL=http://localhost:3001
```

### 2. Запуск бэкенда

```bash
cd server
npm install
cp env.example .env
# Отредактируйте server/.env с данными вашей БД
npm run dev
```

Бэкенд будет доступен на `http://localhost:3001`

### 3. Запуск фронтенда

```bash
# В корне проекта
npm install
npm run dev
```

Фронтенд будет доступен на `http://localhost:8080`

## Деплой на Timeweb

### Шаг 1: База данных

1. Создайте PostgreSQL в Timeweb Cloud
2. Примените схему: скопируйте `TIMEWEB_FULL_SCHEMA.sql` в SQL Editor
3. Выполните скрипт

### Шаг 2: Бэкенд

1. Создайте App Platform приложение в Timeweb
2. Подключите GitHub репозиторий
3. Настройки:
   - Root: `server`
   - Build: `npm install && npm run build`
   - Start: `npm start`
   - Port: `3001`
4. Добавьте переменные из `server/env.example`
5. Запишите URL бэкенда

### Шаг 3: Фронтенд

**Вариант A: Статический хостинг**

```bash
# Создайте .env
VITE_API_URL=https://your-backend-url.twc1.net

# Соберите
npm run build

# Загрузите содержимое dist/ на Timeweb Static Hosting
# Скопируйте .htaccess в dist/
```

**Вариант B: App Platform**

1. Создайте новое App Platform приложение
2. Root: `.`
3. Build: `npm install && npm run build`
4. Start: `npx serve -s dist -l 3000`
5. Port: `3000`
6. Environment Variables:
   ```
   VITE_API_URL=https://your-backend-url.twc1.net
   ```

### Шаг 4: Обновите CORS

В бэкенд приложении обновите `ALLOWED_ORIGINS`:
```
https://your-frontend-domain.twc1.net
```

## Проверка работы

1. Откройте домен фронтенда
2. Проверьте консоль браузера (F12) - нет ошибок
3. Попробуйте зарегистрироваться
4. Проверьте Network tab - запросы идут на API

## Troubleshooting

### Страница не загружается

- Проверьте, что `VITE_API_URL` установлен
- Проверьте, что бэкенд доступен
- Проверьте логи в Timeweb Dashboard

### CORS ошибки

- Обновите `ALLOWED_ORIGINS` на бэкенде
- Перезапустите бэкенд

### 404 на роутах

- Убедитесь, что `.htaccess` в `dist/` (для статического хостинга)
- Проверьте настройки SPA роутинга

## Подробные инструкции

- `START_HERE_TIMEWEB.md` - Навигация
- `TIMEWEB_QUICK_DEPLOY.md` - Быстрый деплой
- `TIMEWEB_FULL_DEPLOY.md` - Подробная инструкция
- `DEPLOY_FIX.md` - Исправление проблем
