# 🚀 Быстрый запуск для тестирования

## Шаг 1: Запуск Backend сервера

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together/server

# Загрузите nvm (если используется)
source ~/.nvm/nvm.sh

# Запустите сервер в режиме разработки (использует tsx для прямого запуска TypeScript)
npm run dev
```

Сервер запустится на `http://localhost:3001`

**Важно:** Убедитесь, что в `server/.env` или `server/.env.production` настроены:
- `DATABASE_URL` - подключение к PostgreSQL
- `JWT_SECRET` - секретный ключ для JWT
- `PORT=3001` - порт сервера

## Шаг 2: Запуск Frontend

В **новом терминале**:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Загрузите nvm (если используется)
source ~/.nvm/nvm.sh

# Убедитесь, что есть .env файл с VITE_API_URL
echo "VITE_API_URL=http://localhost:3001" > .env

# Запустите dev сервер
npm run dev
```

Frontend запустится на `http://localhost:5173`

## Шаг 3: Тестирование API

В **третьем терминале**:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Загрузите nvm (если используется)
source ~/.nvm/nvm.sh

# Запустите тестовый скрипт
API_URL=http://localhost:3001 node test-pagination-api.js
```

## Шаг 4: Тестирование в браузере

1. Откройте `http://localhost:5173`
2. Откройте DevTools (F12)
3. Перейдите на вкладку **Network**
4. Прокрутите до секции "Ближайшие поездки"
5. Проверьте запрос к `/api/rides`:
   - ✅ URL содержит `page=1&pageSize=5&includePagination=true`
   - ✅ Статус: 200
   - ✅ Ответ содержит объект с `data`, `total`, `totalPages`

## Проверка пагинации

### На главной странице:
1. Если поездок > 5, должна отображаться пагинация
2. Нажмите "Следующая страница"
3. Проверьте, что загрузились другие поездки

### В поиске:
1. Откройте `/search`
2. Введите параметры поиска
3. Если результатов > 10, должна отображаться пагинация
4. Проверьте, что фильтры сохраняются при смене страницы

## Устранение проблем

### Backend не запускается:
- Проверьте, что PostgreSQL доступен
- Проверьте `DATABASE_URL` в `.env`
- Проверьте, что порт 3001 свободен

### Frontend не подключается к API:
- Проверьте `VITE_API_URL` в `.env`
- Проверьте CORS настройки в backend
- Убедитесь, что backend запущен

### Ошибки CORS:
- Добавьте в `server/.env`:
  ```
  ALLOWED_ORIGINS=http://localhost:5173
  ```

## Быстрая проверка без запуска

Если не хотите запускать серверы, можно проверить код:

```bash
# Проверка синтаксиса TypeScript (без компиляции)
cd server
npx tsc --noEmit --skipLibCheck api/rides/list.ts

# Проверка линтера
cd ..
npm run lint
```

