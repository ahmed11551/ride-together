# ✅ Готово к деплою на Timeweb

## ✅ Все исправления применены

### 1. Проблема с React chunks - РЕШЕНА
- ✅ Entry chunk содержит ВСЕ React-зависимое
- ✅ Общий vendor chunk больше НЕ создается
- ✅ Размер entry chunk: ~327 KB (приемлемо)

### 2. Проблема с Supabase - РЕШЕНА
- ✅ Supabase добавлен в `optimizeDeps.include`
- ✅ Настроено преобразование CommonJS → ESM
- ✅ Ошибка `exports is not defined` исправлена

### 3. Production сборка - РАБОТАЕТ
- ✅ Сборка проходит успешно
- ✅ Все chunks создаются правильно
- ✅ Нет ошибок компиляции

## 📋 Настройки для Timeweb Cloud

### Frontend (Static Hosting или App Platform)

#### 1. Framework Settings
```
Framework: React/Vite/Static Site
Build Command: npm run build
Build Directory: dist
Node.js Version: 20 или 22
```

#### 2. Environment Variables
Добавьте в Timeweb Dashboard:
```
VITE_API_URL=https://your-backend-url.twc1.net
VITE_WS_URL=wss://your-backend-url.twc1.net
```

**ВАЖНО:** Если используете кастомный auth (не Supabase), то:
- `VITE_SUPABASE_URL` и `VITE_SUPABASE_ANON_KEY` можно НЕ указывать
- Приложение будет работать с кастомным backend

#### 3. Nginx/Apache Configuration

**Для Nginx** (если используете):
- Используйте `nginx-timeweb.conf` из репозитория
- Или добавьте в конфигурацию:
```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

**Для Apache** (если используете):
- Используйте `.htaccess` из репозитория
- Или добавьте `_redirects` файл (для Netlify/Vercel совместимости)

#### 4. Dockerfile (если используете Docker)
- Используйте `Dockerfile` из репозитория
- Он настроен для React/Vite приложения

## 🚀 Шаги деплоя

### Вариант 1: Static Hosting (рекомендуется для frontend)

1. **В Timeweb Dashboard:**
   - Создайте новый Static Hosting проект
   - Подключите GitHub репозиторий
   - Установите настройки:
     - Framework: React/Vite/Static Site
     - Build Command: `npm run build`
     - Build Directory: `dist`
     - Node.js: 20 или 22

2. **Environment Variables:**
   - Добавьте `VITE_API_URL` и `VITE_WS_URL`
   - Если не используете Supabase, можно не добавлять Supabase переменные

3. **Запустите деплой:**
   - Timeweb автоматически соберет проект
   - Дождется завершения сборки
   - Задеплоит в production

### Вариант 2: App Platform (если нужен Node.js)

1. **В Timeweb Dashboard:**
   - Создайте новый App Platform проект
   - Выберите Node.js
   - Подключите GitHub репозиторий
   - Установите настройки:
     - Build Command: `npm run build`
     - Start Command: `npm run preview` (или используйте Nginx для статики)
     - Node.js: 20 или 22

2. **Environment Variables:**
   - Добавьте те же переменные, что и в Static Hosting

3. **Запустите деплой**

## ✅ Проверка после деплоя

1. **Откройте сайт в браузере**
2. **Откройте DevTools (F12) → Console**
3. **Проверьте:**
   - ✅ НЕТ ошибки `__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED`
   - ✅ НЕТ ошибки `exports is not defined`
   - ✅ НЕТ ошибок загрузки chunks
   - ✅ Страница загружается
   - ✅ Компоненты отображаются

4. **Проверьте Network tab:**
   - ✅ Entry chunk (`index-*.js`) загружается первым
   - ✅ Размер entry chunk: ~327 KB
   - ✅ НЕТ общего `vendor-*.js` chunk

## 🔧 Если что-то не работает

### Проблема: Белый экран
- Проверьте, что `dist` директория правильно указана
- Проверьте, что Nginx/Apache настроен на fallback к `index.html`
- Проверьте консоль браузера на ошибки

### Проблема: Ошибки в консоли
- Проверьте environment variables
- Проверьте, что backend доступен
- Проверьте CORS настройки на backend

### Проблема: Chunks не загружаются
- Проверьте, что все файлы задеплоены
- Проверьте пути к assets (должны быть относительные)
- Проверьте, что `base` в `vite.config.ts` правильный (если нужен)

## 📝 Файлы для деплоя

Все необходимые файлы уже в репозитории:
- ✅ `vite.config.ts` - правильная конфигурация
- ✅ `Dockerfile` - для Docker деплоя
- ✅ `nginx-timeweb.conf` - для Nginx
- ✅ `.htaccess` - для Apache
- ✅ `_redirects` - для SPA routing
- ✅ `env.example` - пример переменных окружения

## 🎉 Готово!

Все исправления применены, production сборка работает. Можно деплоить на Timeweb!
