# 🔧 Исправление проблем деплоя на Timeweb

## Проблемы из лога деплоя

### ✅ Исправлено

1. **Dockerfile** - создан правильный Dockerfile для фронтенда (React/Vite)
   - Удален Angular CLI (не нужен для React проекта)
   - Исправлена пустая строка в многострочной команде
   - Используется multi-stage build с Nginx

2. **Dynamic import warning** - исправлен в `AuthContext.tsx`
   - `analytics.ts` теперь импортируется только динамически
   - Убрано статическое импортирование `trackUserAction`

3. **SPA роутинг** - создан `_redirects` для Netlify/Vercel
   - `.htaccess` уже есть для Apache
   - `nginx-timeweb.conf` обновлен

4. **Vite plugin warnings** - уже исправлено ранее
   - Используется `order: 'post'` и `handler` вместо deprecated опций

### ⚠️ Требует действий на Timeweb

1. **Environment Variables** - КРИТИЧНО
   ```bash
   # Добавьте в Timeweb Dashboard → Environment Variables:
   VITE_API_URL=https://your-backend-url.twc1.net
   VITE_WS_URL=wss://your-backend-url.twc1.net
   # Опционально:
   VITE_YANDEX_MAPS_API_KEY=your_key
   VITE_GA_MEASUREMENT_ID=your_id
   ```

2. **Nginx конфигурация** - проверьте, применена ли
   - Скопируйте `nginx-timeweb.conf` в настройки Nginx на Timeweb
   - Или используйте `.htaccess` если используется Apache

3. **Static hosting fallback** - убедитесь, что настроен
   - Все запросы должны возвращаться на `/index.html`
   - Проверьте настройки Static Hosting в Timeweb

## ⚠️ КРИТИЧНО: Настройки фреймворка в Timeweb

**Перед деплоем проверьте настройки в Timeweb Dashboard:**

1. **Фреймворк:** Должен быть `React`, `Vite` или `Static Site` (НЕ Angular!)
2. **Версия окружения:** Node.js 20 или 22
3. **Команда сборки:** `npm run build`
4. **Директория сборки:** `dist`

Подробнее см. `TIMEWEB_DEPLOY_CONFIG.md`

## Инструкции по деплою

### 1. Подготовка

```bash
# Обновить browserslist
npx update-browserslist-db@latest

# Исправить уязвимости
npm audit fix

# Локальная проверка сборки
npm run build
```

### 2. Настройка Timeweb

1. **Добавьте Environment Variables:**
   - `VITE_API_URL` - URL вашего бэкенда
   - `VITE_WS_URL` - WebSocket URL (опционально)
   - Другие опциональные переменные из `env.example`

2. **Настройте Nginx/Apache:**
   - Если Nginx: используйте `nginx-timeweb.conf`
   - Если Apache: `.htaccess` уже настроен

3. **Проверьте Static Hosting:**
   - Убедитесь, что fallback на `index.html` настроен
   - Проверьте, что `dist/` директория правильно указана

### 3. Деплой

```bash
# Коммит изменений
git add -A
git commit -m "Исправления для деплоя на Timeweb"
git push

# Timeweb автоматически соберет и задеплоит
```

### 4. Проверка после деплоя

1. Откройте сайт: `https://your-domain.twc1.net`
2. Проверьте консоль браузера (F12) - не должно быть ошибок
3. Проверьте Network tab - все ресурсы должны загружаться
4. Проверьте роутинг - переходы между страницами должны работать

## Troubleshooting

### Белый экран / "No content found"

**Причина:** Отсутствуют environment variables или неправильная конфигурация сервера

**Решение:**
1. Проверьте Environment Variables в Timeweb Dashboard
2. Проверьте, что `VITE_API_URL` указан правильно
3. Проверьте консоль браузера на ошибки
4. Проверьте Network tab - все ли ресурсы загружаются

### 404 на всех страницах кроме `/`

**Причина:** Не настроен fallback на `index.html` для SPA роутинга

**Решение:**
1. Примените `nginx-timeweb.conf` или `.htaccess`
2. Убедитесь, что `try_files $uri $uri/ /index.html;` настроен в Nginx
3. Проверьте, что `.htaccess` скопирован в `dist/` после сборки

### Ошибки загрузки ресурсов

**Причина:** Неправильные пути к ресурсам

**Решение:**
1. Проверьте `vite.config.ts` - `base` должен быть `/` для корня
2. Проверьте, что все пути в коде относительные
3. Проверьте Network tab - какие ресурсы не загружаются

### API запросы не работают

**Причина:** Неправильный `VITE_API_URL` или CORS проблемы

**Решение:**
1. Проверьте `VITE_API_URL` в Environment Variables
2. Проверьте CORS настройки на бэкенде
3. Проверьте Network tab - какие запросы падают

## Дополнительные улучшения

### Обновить browserslist

```bash
npx update-browserslist-db@latest
```

### Исправить npm audit

```bash
npm audit fix
# Если есть критические уязвимости:
npm audit fix --force
```

### Оптимизация сборки

Уже настроено в `vite.config.ts`:
- Code splitting
- Tree shaking
- Minification
- Gzip compression (через Nginx)

## Чеклист перед деплоем

- [ ] Environment Variables добавлены в Timeweb
- [ ] Nginx/Apache конфигурация применена
- [ ] `.htaccess` скопирован в `dist/` (если Apache)
- [ ] Локальная сборка работает (`npm run build`)
- [ ] Нет ошибок в консоли при локальном preview (`npm run preview`)
- [ ] `npm audit fix` выполнен
- [ ] `browserslist` обновлен
- [ ] Изменения закоммичены и запушены

## Полезные ссылки

- [Timeweb Documentation](https://timeweb.cloud/docs)
- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html)
- [Nginx SPA Configuration](https://nginx.org/en/docs/http/ngx_http_core_module.html#try_files)
