# 🚀 Быстрая настройка VPS на REG.RU

## ✅ VPS создан!

**IP-адрес:** `194.67.124.123`

---

## 📋 Что нужно сделать сейчас:

### Шаг 1: Получите доступ к серверу

У вас есть два варианта:

#### Вариант A: Получить пароль от root
1. Зайдите в панель REG.RU: https://cloud.reg.ru/panel/servers
2. Найдите ваш сервер `194.67.124.123`
3. Откройте его и найдите раздел "Пароли" или "Access"
4. Скопируйте пароль root или сбросьте его, если нужно

#### Вариант B: Добавить SSH ключ
1. Сгенерируйте SSH ключ (если нет):
   ```bash
   ssh-keygen -t ed25519 -C "your_email@example.com"
   ```
2. Скопируйте публичный ключ:
   ```bash
   cat ~/.ssh/id_ed25519.pub
   ```
3. Добавьте его в панели REG.RU в настройках сервера

---

### Шаг 2: Запустите автоматическую настройку

После того, как у вас есть доступ, запустите:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together
./scripts/auto-setup-regru.sh 194.67.124.123 root
```

**Или если нужен другой пользователь:**

```bash
./scripts/auto-setup-regru.sh 194.67.124.123 ubuntu
```

---

## 🎯 Что делает скрипт:

1. ✅ Устанавливает Node.js 20.x
2. ✅ Устанавливает PostgreSQL
3. ✅ Устанавливает Nginx
4. ✅ Устанавливает PM2
5. ✅ Настраивает firewall
6. ✅ Создает базу данных
7. ✅ Настраивает Backend и Frontend
8. ✅ Настраивает Nginx
9. ✅ Получает SSL сертификат (опционально)

---

## 🔧 Ручная настройка (если скрипт не подходит)

### 1. Подключитесь к серверу:

```bash
ssh root@194.67.124.123
# Введите пароль, когда попросит
```

### 2. Обновите систему:

```bash
apt-get update && apt-get upgrade -y
```

### 3. Установите Node.js:

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
```

### 4. Установите PostgreSQL:

```bash
apt-get install -y postgresql postgresql-contrib
systemctl start postgresql
systemctl enable postgresql
```

### 5. Установите Nginx:

```bash
apt-get install -y nginx
systemctl start nginx
systemctl enable nginx
```

### 6. Установите PM2:

```bash
npm install -g pm2
```

### 7. Создайте базу данных:

```bash
sudo -u postgres psql
```

В PostgreSQL выполните:

```sql
CREATE DATABASE ride_together;
CREATE USER ride_user WITH ENCRYPTED PASSWORD 'ВАШ_СЛОЖНЫЙ_ПАРОЛЬ';
GRANT ALL PRIVILEGES ON DATABASE ride_together TO ride_user;
ALTER DATABASE ride_together OWNER TO ride_user;
\q
```

### 8. Скопируйте проект на сервер:

С вашего локального компьютера:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together
tar -czf ride-together.tar.gz --exclude='node_modules' --exclude='.git' .
scp ride-together.tar.gz root@194.67.124.123:/var/www/
```

На сервере:

```bash
cd /var/www
tar -xzf ride-together.tar.gz -C ride-together
cd ride-together
```

### 9. Настройте Backend:

```bash
cd server
cp env.regru.example .env.production
nano .env.production  # Отредактируйте файл
npm install --production
npm run build
```

### 10. Импортируйте схему БД:

```bash
sudo -u postgres psql ride_together < /var/www/ride-together/TIMEWEB_FULL_SCHEMA.sql
```

### 11. Запустите Backend через PM2:

```bash
pm2 start dist/index.js --name ride-backend
pm2 save
pm2 startup
```

### 12. Соберите и настройте Frontend:

```bash
cd /var/www/ride-together
cp env.regru.example .env.production
nano .env.production  # Укажите API URL
npm install
npm run build
cp -r dist/* /var/www/html/
```

### 13. Настройте Nginx:

Создайте файл `/etc/nginx/sites-available/ride-together`:

```nginx
server {
    listen 80;
    server_name 194.67.124.123;  # Или ваш домен
    
    root /var/www/html;
    index index.html;
    
    # Frontend
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Backend API
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # WebSocket
    location /socket.io {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

Активируйте конфигурацию:

```bash
ln -sf /etc/nginx/sites-available/ride-together /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

---

## 🎉 После настройки:

1. Откройте в браузере: `http://194.67.124.123`
2. Проверьте работу API: `http://194.67.124.123/api/health`
3. Настройте домен (если есть)
4. Получите SSL сертификат через Certbot

---

## 📝 Полезные команды:

```bash
# Просмотр логов Backend
pm2 logs ride-backend

# Перезапуск Backend
pm2 restart ride-backend

# Статус Nginx
systemctl status nginx

# Статус PostgreSQL
systemctl status postgresql

# Подключение к БД
sudo -u postgres psql ride_together
```

---

**Нужна помощь?** Запустите автоматический скрипт или следуйте инструкциям выше! 🚀

