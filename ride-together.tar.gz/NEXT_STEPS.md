# 🎯 Следующие шаги для настройки VPS

## ✅ Ваш VPS создан!

**Публичный IP-адрес:** `194.67.124.123`  
**Приватный IP-адрес:** `192.168.0.107`  
**Приватная сеть:** `private_network_115049195` (subnet_115049195)

---

## 📋 Что делать сейчас:

### 1️⃣ Получите пароль от root

1. Зайдите в панель REG.RU: https://cloud.reg.ru/panel/servers
2. Найдите ваш сервер `194.67.124.123`
3. Откройте раздел **"Доступ"** или **"Пароли"**
4. **Скопируйте пароль root**

---

### 2️⃣ Запустите автоматическую настройку

Откройте терминал и выполните:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together
./scripts/quick-setup-regru.sh 194.67.124.123 root
```

**Скрипт спросит пароль** - вставьте пароль root из панели REG.RU.

**Скрипт автоматически:**
- ✅ Установит Node.js, PostgreSQL, Nginx, PM2
- ✅ Создаст базу данных
- ✅ Настроит firewall
- ✅ Подготовит все директории

**Это займет 3-5 минут.**

---

### 3️⃣ Скопируйте проект на сервер

После настройки скопируйте проект:

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Создайте архив (без node_modules и .git)
tar -czf ride-together.tar.gz \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='dist' \
  --exclude='*.log' \
  .

# Скопируйте на сервер (введет пароль)
scp ride-together.tar.gz root@194.67.124.123:/var/www/

# Подключитесь к серверу (введет пароль)
ssh root@194.67.124.123
```

**На сервере:**

```bash
cd /var/www
tar -xzf ride-together.tar.gz -C ride-together
cd ride-together
```

---

### 4️⃣ Настройте Backend

**На сервере выполните:**

```bash
cd /var/www/ride-together/server

# Скопируйте конфигурацию
cp env.regru.example .env.production

# Получите информацию о БД (пароль был создан скриптом)
cat /tmp/regru-db-info.txt

# Отредактируйте .env.production
nano .env.production
```

**В `.env.production` укажите:**
- `DATABASE_URL` - из `/tmp/regru-db-info.txt`
- `JWT_SECRET` - сгенерируйте: `openssl rand -base64 32`
- `ALLOWED_ORIGINS=http://194.67.124.123`
- `FRONTEND_URL=http://194.67.124.123`

**Установите и соберите:**

```bash
npm install --production
npm run build

# Импортируйте схему БД
sudo -u postgres psql ride_together < ../TIMEWEB_FULL_SCHEMA.sql

# Запустите через PM2
pm2 start dist/index.js --name ride-backend
pm2 save
pm2 startup
```

---

### 5️⃣ Настройте Frontend

**На сервере:**

```bash
cd /var/www/ride-together

# Создайте .env.production
echo 'VITE_API_URL=http://194.67.124.123/api
VITE_WS_URL=ws://194.67.124.123' > .env.production

# Установите и соберите
npm install
npm run build

# Скопируйте в Nginx
cp -r dist/* /var/www/html/
chown -R www-data:www-data /var/www/html
```

---

### 6️⃣ Настройте Nginx

**На сервере создайте конфигурацию:**

```bash
cat > /etc/nginx/sites-available/ride-together <<'EOF'
server {
    listen 80;
    server_name 194.67.124.123;
    
    root /var/www/html;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /socket.io {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
EOF

# Активируйте
ln -sf /etc/nginx/sites-available/ride-together /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
```

---

## ✅ Готово!

Откройте в браузере: **http://194.67.124.123**

---

## 📚 Дополнительная документация

- **Полная инструкция:** `QUICK_START_REG_RU.md`
- **Детальная настройка:** `SETUP_REG_RU_VPS.md`
- **Рекомендации по конфигурации:** `REG_RU_VPS_CONFIGURATION.md`
- **Информация о сети:** `REG_RU_NETWORK_INFO.md`

---

**Начните с шага 1 - получите пароль root в панели REG.RU!** 🔑

