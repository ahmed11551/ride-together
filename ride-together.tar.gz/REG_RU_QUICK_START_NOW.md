# ⚡ БЫСТРЫЙ СТАРТ - Миграция на REG.RU ПРЯМО СЕЙЧАС

## ✅ Токен работает! API подключен!

---

## 🚀 ТРИ ПРОСТЫХ ШАГА:

### Шаг 1: Создайте VPS на REG.RU (5 минут, ~350-500₽/месяц)

**Вариант A: Через веб-интерфейс** (рекомендуется)
1. Зайдите на https://reg.ru
2. **Облачный VPS** → **Заказать**
3. Выберите: **Ubuntu 22.04** или **Debian 12**
4. Конфигурация: **2 vCPU, 2GB RAM, 20GB SSD** (минимум)
5. Оплатите
6. Запишите **IP адрес**

**Вариант B: Через API** (если поддерживается)
```bash
# Получить доступные образы
./scripts/regru-api-client.sh images

# Найти Ubuntu 22.04 (id образов в выводе)
# Создать через API (если endpoint доступен)
```

---

### Шаг 2: Автоматическая настройка (15 минут)

```bash
cd /Users/ahmeddevops/Desktop/ride/ride-together

# Запустить автоматическую настройку
./scripts/auto-setup-regru.sh YOUR_VPS_IP root
```

**Что спросит скрипт:**
- Создать БД? → **y**
- URL репозитория → ваш GitHub/GitLab URL
- Домен API → например: **api.your-domain.ru**
- Домен Frontend → например: **your-domain.ru**
- SSL сертификат? → **y** (если домен настроен)

**Автоматически установится:**
- ✅ Node.js 20.x
- ✅ PostgreSQL
- ✅ Nginx
- ✅ PM2
- ✅ Backend (установка, сборка, запуск)
- ✅ Frontend (сборка, развертывание)
- ✅ SSL (если домен)

---

### Шаг 3: Импорт данных (если нужно)

Если есть данные с Timeweb:

```bash
# Экспорт с Timeweb
twc database backup create $TIMEWEB_DB_ID

# Импорт на REG.RU
scp backup.sql root@YOUR_VPS_IP:/tmp/
ssh root@YOUR_VPS_IP "psql -U ride_user -d ride_together < /tmp/backup.sql"
```

---

## 🎯 Готово!

После шага 2 ваше приложение будет полностью настроено и работать!

**Проверка:**
```bash
ssh root@YOUR_VPS_IP "curl http://localhost:3001/health"
ssh root@YOUR_VPS_IP "pm2 status"
```

---

## 📝 Доступные образы (из API):

- ✅ **Ubuntu 22.04** - рекомендуется
- ✅ **Ubuntu 24.04** - новее
- ✅ **Debian 12** - альтернатива

**Найдите нужный образ:**
```bash
./scripts/regru-api-client.sh images | grep -i "ubuntu-22"
```

---

## 🔧 Если нужно использовать API:

```bash
# Проверить авторизацию
./scripts/regru-api-client.sh check

# Получить образы
./scripts/regru-api-client.sh images

# Получить список серверов (если endpoint доступен)
./scripts/regru-api-client.sh servers
```

---

## ✅ Итого:

1. ✅ Токен работает
2. ✅ API подключен
3. ✅ Образы получены
4. ✅ Скрипты готовы
5. ⏳ Осталось: создать VPS и запустить настройку

**Начните с создания VPS на REG.RU, затем запустите автоматическую настройку!** 🚀

