# 🚀 Начните отсюда: Деплой всего на Timeweb

## ✅ Все на Timeweb: Фронтенд + Бэкенд + БД

## 📋 Быстрая навигация

1. **`КОПИРУЙ_В_TIMEWEB_ПОЛНЫЙ.txt`** - Краткая инструкция (копируй-вставляй)
2. **`TIMEWEB_QUICK_DEPLOY.md`** - Быстрый деплой (~30 минут)
3. **`TIMEWEB_FULL_DEPLOY.md`** - Подробная инструкция со всеми вариантами

## 🎯 Три простых шага

### 1️⃣ База данных (5 минут)

1. Timeweb Cloud → Создать PostgreSQL
2. SQL Editor → Скопировать `TIMEWEB_FULL_SCHEMA.sql` → Выполнить

### 2️⃣ Бэкенд (10 минут)

1. Создайте `server/.env` из `server/env.example`
2. Заполните данные БД и сгенерируйте `JWT_SECRET`
3. В Timeweb App Platform:
   - Создать приложение
   - GitHub репозиторий
   - Root: `server`
   - Build: `npm install && npm run build`
   - Start: `npm start`
   - Port: `3001`
   - Добавить переменные из `.env`
4. Задеплойте и запишите URL бэкенда

### 3️⃣ Фронтенд (10 минут)

**Вариант A - Статический хостинг (рекомендуется):**

1. Соберите фронтенд:
   ```bash
   ./scripts/build-for-timeweb.sh
   # Или вручную: создайте .env с VITE_API_URL, затем npm run build
   ```

2. В Timeweb Static Hosting:
   - Создать статический сайт
   - Загрузить содержимое папки `dist/`
   - Скопировать `.htaccess` в `dist/` (для SPA роутинга)

**Вариант B - App Platform:**

1. В Timeweb App Platform:
   - Создать новое приложение
   - GitHub репозиторий
   - Root: `.` (корень)
   - Build: `npm install && npm run build`
   - Start: `npx serve -s dist -l 3000`
   - Port: `3000`
   - Environment Variables:
     ```
     VITE_API_URL=https://your-backend-url.twc1.net
     VITE_WS_URL=wss://your-backend-url.twc1.net
     ```

### 4️⃣ Обновление CORS (2 минуты)

После получения домена фронтенда:

1. В бэкенд приложении обновите `ALLOWED_ORIGINS`:
   ```
   https://your-frontend-domain.twc1.net
   ```

2. Перезапустите бэкенд

## 📚 Подробные инструкции

- **Краткая:** `КОПИРУЙ_В_TIMEWEB_ПОЛНЫЙ.txt`
- **Быстрая:** `TIMEWEB_QUICK_DEPLOY.md`
- **Полная:** `TIMEWEB_FULL_DEPLOY.md`

## 🔧 Полезные скрипты

- `./scripts/build-for-timeweb.sh` - Сборка фронтенда для Timeweb
- `./scripts/prepare-deploy.sh` - Подготовка к деплою
- `./scripts/check-deploy.sh` - Проверка готовности

## ✅ Преимущества деплоя на Timeweb

✅ Все в одном месте  
✅ Нет проблем с CORS между разными доменами  
✅ Проще управление  
✅ Единый биллинг  
✅ Быстрая связь между сервисами  
✅ Меньше точек отказа  

## 🎯 Готовность: 100%

Все файлы готовы, инструкции созданы, скрипты подготовлены.

**Начните с:** `КОПИРУЙ_В_TIMEWEB_ПОЛНЫЙ.txt`

---

**Время деплоя:** ~30 минут  
**Сложность:** Средняя  
**Статус:** ✅ Готово к деплою на Timeweb
