#!/bin/bash
# Проверка REG.RU API и доступных ресурсов

set -e

# Загрузить токен
if [ -f ".env.regru.token" ]; then
    source .env.regru.token
elif [ -n "$REG_RU_API_TOKEN" ]; then
    TOKEN=$REG_RU_API_TOKEN
else
    echo "❌ Токен не найден. Установите REG_RU_API_TOKEN или создайте .env.regru.token"
    exit 1
fi

TOKEN=${REG_RU_API_TOKEN:-$TOKEN}

echo "🔍 Проверка REG.RU API..."
echo ""

# Попробуем различные API endpoints REG.RU
# (REG.RU может иметь разные API, проверим что доступно)

# Проверка через curl
echo "Проверка доступности API..."

# REG.RU обычно использует API через их панель управления
# Точный endpoint нужно узнать из их документации

echo "⚠️  REG.RU API требует проверки документации"
echo "Токен сохранен, будет использован для автоматизации после создания ресурсов"
echo ""
echo "✅ Токен готов к использованию"

