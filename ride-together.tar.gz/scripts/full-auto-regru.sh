#!/bin/bash
# Полная автоматизация: создание VPS через API + настройка

set -e

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

log_section() {
    echo -e "\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}$1${NC}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

# Проверка зависимостей
if ! command -v jq &> /dev/null; then
    log_warning "jq не установлен. Установите: brew install jq"
    log_info "Скрипт будет работать, но с ограниченной функциональностью"
fi

log_section "🚀 Полная автоматизация миграции на REG.RU"

# Шаг 1: Проверка API и получение тарифов
log_section "Шаг 1: Проверка REG.RU API"

# Проверка токена
if [ ! -f ".env.regru.token" ] && [ -z "$REG_RU_API_TOKEN" ]; then
    log_error "Токен не найден"
    exit 1
fi

log_info "Используя API клиент для REG.RU..."
log_info "Проверяю доступные тарифы и образы..."

# Используем API клиент
if [ -f "scripts/regru-api-client.sh" ]; then
    chmod +x scripts/regru-api-client.sh
    
    # Проверка авторизации
    log_info "Проверка авторизации через API..."
    ./scripts/regru-api-client.sh check || log_warning "Ошибка проверки авторизации"
    
    log_info "Получение списка тарифов..."
    ./scripts/regru-api-client.sh tariffs | head -20 || log_warning "Не удалось получить тарифы"
    
    log_info "Получение списка образов..."
    ./scripts/regru-api-client.sh images | head -20 || log_warning "Не удалось получить образы"
else
    log_warning "API клиент не найден. Продолжаю с ручной настройкой..."
fi

# Шаг 2: Варианты продолжения
log_section "Варианты продолжения"

echo "Выберите вариант:"
echo "1. VPS уже создан - настроить автоматически"
echo "2. Создать VPS через API (если поддерживается)"
echo "3. Инструкция по ручному созданию VPS"
echo ""
read -p "Ваш выбор [1-3]: " choice

case $choice in
    1)
        read -p "IP адрес VPS: " VPS_IP
        read -p "SSH пользователь [root]: " SSH_USER
        SSH_USER=${SSH_USER:-root}
        
        log_section "Запуск автоматической настройки"
        ./scripts/auto-setup-regru.sh "$VPS_IP" "$SSH_USER"
        ;;
    2)
        log_info "Создание VPS через API..."
        log_warning "ВНИМАНИЕ: Это действие требует оплаты!"
        
        read -p "Название сервера: " SERVER_NAME
        read -p "ID тарифа: " TARIFF_ID
        read -p "ID образа (ОС): " IMAGE_ID
        
        log_warning "Создание сервера требует оплаты. Продолжить? (yes/no)"
        read -p "> " confirm
        if [ "$confirm" != "yes" ]; then
            log_info "Отменено"
            exit 0
        fi
        
        if [ -f "scripts/regru-api-client.sh" ]; then
            log_info "Создание сервера через API..."
            SERVER_INFO=$(./scripts/regru-api-client.sh create-server "$SERVER_NAME" "$TARIFF_ID" "$IMAGE_ID")
            echo "$SERVER_INFO"
            
            # Извлечь IP из ответа
            VPS_IP=$(echo "$SERVER_INFO" | jq -r '.server.ip // empty' 2>/dev/null || echo "")
            
            if [ -z "$VPS_IP" ]; then
                log_warning "Не удалось получить IP автоматически"
                read -p "Введите IP адрес сервера вручную: " VPS_IP
            else
                log_success "Сервер создан! IP: $VPS_IP"
            fi
            
            log_info "Ожидание готовности сервера (30 секунд)..."
            sleep 30
            
            log_section "Запуск автоматической настройки"
            ./scripts/auto-setup-regru.sh "$VPS_IP" "root"
        else
            log_error "API клиент не найден"
        fi
        ;;
    3)
        log_section "Инструкция по созданию VPS"
        echo "1. Зайдите на https://reg.ru"
        echo "2. Облачный VPS → Заказать"
        echo "3. Выберите: Ubuntu 22.04, 2 vCPU, 2GB RAM"
        echo "4. Оплатите (~350-500₽/месяц)"
        echo "5. Запишите IP адрес"
        echo ""
        echo "После создания запустите:"
        echo "  ./scripts/auto-setup-regru.sh YOUR_VPS_IP root"
        ;;
    *)
        log_error "Неверный выбор"
        exit 1
        ;;
esac

log_success "Готово!"

