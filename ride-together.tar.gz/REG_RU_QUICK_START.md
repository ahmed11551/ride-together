# 🚀 Быстрый старт на REG.RU

## 📋 Краткая инструкция

### 1. Создание VPS на REG.RU

1. Войдите в панель управления REG.RU
2. Перейдите в раздел "Облачный VPS"
3. Создайте сервер:
   - **ОС:** Ubuntu 22.04 или Debian 12
   - **Конфигурация:** Минимум 2 vCPU, 2GB RAM, 20GB SSD
   - Запишите IP адрес

---

### 2. Автоматическая настройка VPS

```bash
# Подключитесь к серверу
ssh root@your-vps-ip

# Скопируйте и запустите скрипт настройки
# (или скачайте из репозитория)
wget https://raw.githubusercontent.com/your-repo/ride-together/main/scripts/setup-regru-vps.sh
chmod +x setup-regru-vps.sh
sudo ./setup-regru-vps.sh
```

Скрипт установит:
- ✅ Node.js 20.x
- ✅ PostgreSQL
- ✅ Nginx
- ✅ PM2
- ✅ Настроит firewall
- ✅ Создаст базу данных (по желанию)

---

### 3. Подготовка базы данных

#### Вариант A: Экспорт с Timeweb

```bash
# Создать бэкап
twc database backup create $TIMEWEB_DB_ID

# Скачать бэкап (или использовать pg_dump)
pg_dump -h timeweb-db-host -U user -d database > backup.sql

# На VPS: импортировать
psql -U ride_user -d ride_together < backup.sql
```

#### Вариант B: Создать новую БД

```bash
# На VPS
sudo -u postgres psql

CREATE DATABASE ride_together;
CREATE USER ride_user WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE ride_together TO ride_user;
\q

# Применить схему
psql -U ride_user -d ride_together < TIMEWEB_FULL_SCHEMA.sql
```

---

### 4. Деплой Backend

```bash
# На VPS: клонировать репозиторий
cd /var/www
git clone https://github.com/your-username/ride-together.git
cd ride-together

# Настроить Backend
cd server
cp env.regru.example .env.production
nano .env.production  # Заполнить переменные

# Установить зависимости и собрать
npm install
npm run build

# Запустить через PM2
pm2 start dist/index.js --name ride-backend
pm2 save
pm2 startup
```

---

### 5. Деплой Frontend

```bash
# На VPS (или локально)
cd /var/www/ride-together
cp env.regru.example .env.production
nano .env.production  # Обновить VITE_API_URL

# Собрать
npm install
npm run build

# Скопировать в веб-директорию
sudo cp -r dist/* /var/www/html/
sudo chown -R www-data:www-data /var/www/html
```

---

### 6. Настройка Nginx

```bash
# Скопировать конфигурацию
sudo cp /var/www/ride-together/nginx-regru.conf.example /etc/nginx/sites-available/ride-together
sudo nano /etc/nginx/sites-available/ride-together  # Обновить домены

# Активировать
sudo ln -s /etc/nginx/sites-available/ride-together /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

### 7. Настройка SSL

```bash
# Получить сертификат
sudo certbot --nginx -d your-domain.ru -d www.your-domain.ru -d api.your-domain.ru

# Автообновление уже настроено
```

---

### 8. Проверка

```bash
# Health check Backend
curl http://localhost:3001/health
curl https://api.your-domain.ru/health

# Проверить PM2
pm2 status
pm2 logs ride-backend

# Проверить Nginx
sudo systemctl status nginx
sudo tail -f /var/log/nginx/error.log
```

---

## 🔄 Автоматический деплой

Используйте скрипт для автоматического деплоя:

```bash
# С локальной машины
./scripts/deploy-regru.sh root@your-vps-ip
```

---

## 📝 Важные файлы

- `server/env.regru.example` - переменные окружения Backend
- `env.regru.example` - переменные окружения Frontend
- `nginx-regru.conf.example` - конфигурация Nginx
- `scripts/setup-regru-vps.sh` - автоматическая настройка VPS
- `scripts/deploy-regru.sh` - автоматический деплой

---

## 🆘 Полезные команды

```bash
# PM2 управление
pm2 restart ride-backend
pm2 logs ride-backend
pm2 status

# PostgreSQL
sudo -u postgres psql -d ride_together
pg_dump -U ride_user ride_together > backup.sql

# Nginx
sudo nginx -t
sudo systemctl reload nginx
sudo tail -f /var/log/nginx/error.log
```

---

## ✅ Чек-лист

- [ ] VPS создан на REG.RU
- [ ] VPS настроен (скрипт setup-regru-vps.sh)
- [ ] База данных создана и импортирована
- [ ] Backend задеплоен и запущен
- [ ] Frontend собран и загружен
- [ ] Nginx настроен
- [ ] SSL сертификат получен
- [ ] Все протестировано

---

**Готово! Ваше приложение работает на REG.RU!** 🎉

