# 📦 План миграции на REG.RU

## 🎯 Структура деплоя на REG.RU

На REG.RU будем использовать:
- **Backend:** VPS/VDS сервер (Ubuntu/Debian)
- **Frontend:** Виртуальный хостинг или на том же VPS
- **База данных:** PostgreSQL на VPS или Managed PostgreSQL

---

## 📋 Пошаговый план миграции

### Этап 1: Подготовка на REG.RU (30 минут)

1. **Создать VPS сервер**
   - Перейти в REG.RU Cloud → VPS
   - Создать сервер (Ubuntu 22.04 или Debian 12)
   - Минимум: 2 vCPU, 2GB RAM, 20GB SSD
   - Записать IP адрес

2. **Создать базу данных PostgreSQL** (если доступна managed БД) или установить на VPS

3. **Настроить домен** (если есть)
   - Добавить домен в панель управления
   - Настроить DNS записи (A-запись на IP VPS)

---

### Этап 2: Экспорт данных с Timeweb (15 минут)

1. **Создать бэкап базы данных**
   ```bash
   # Через twc CLI
   twc database backup create $TIMEWEB_DB_ID
   
   # Или через pg_dump напрямую
   pg_dump -h your-timeweb-db-host -U user -d database > backup.sql
   ```

2. **Экспортировать переменные окружения** (если есть важные данные)

---

### Этап 3: Настройка VPS сервера (1 час)

1. **Подключиться к серверу**
   ```bash
   ssh root@your-reg-ru-vps-ip
   ```

2. **Обновить систему**
   ```bash
   apt update && apt upgrade -y
   ```

3. **Установить Node.js**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
   apt install -y nodejs
   ```

4. **Установить PostgreSQL** (если не managed)
   ```bash
   apt install -y postgresql postgresql-contrib
   systemctl start postgresql
   systemctl enable postgresql
   ```

5. **Установить Nginx** (для reverse proxy и статики)
   ```bash
   apt install -y nginx
   systemctl start nginx
   systemctl enable nginx
   ```

6. **Установить PM2** (для управления Node.js процессами)
   ```bash
   npm install -g pm2
   ```

7. **Настроить Firewall**
   ```bash
   ufw allow 22/tcp
   ufw allow 80/tcp
   ufw allow 443/tcp
   ufw enable
   ```

---

### Этап 4: Импорт базы данных (15 минут)

1. **Создать базу данных и пользователя**
   ```bash
   sudo -u postgres psql
   CREATE DATABASE ride_together;
   CREATE USER ride_user WITH ENCRYPTED PASSWORD 'your_secure_password';
   GRANT ALL PRIVILEGES ON DATABASE ride_together TO ride_user;
   \q
   ```

2. **Импортировать бэкап**
   ```bash
   psql -U ride_user -d ride_together < backup.sql
   ```

3. **Применить схему** (если нужно)
   ```bash
   psql -U ride_user -d ride_together < TIMEWEB_FULL_SCHEMA.sql
   ```

---

### Этап 5: Деплой Backend (30 минут)

1. **Клонировать репозиторий**
   ```bash
   cd /var/www
   git clone https://github.com/your-username/ride-together.git
   cd ride-together
   ```

2. **Установить зависимости**
   ```bash
   cd server
   npm install
   ```

3. **Настроить переменные окружения**
   ```bash
   cp env.production.example .env.production
   nano .env.production
   ```

4. **Обновить .env.production:**
   ```env
   DATABASE_URL=postgresql://ride_user:your_password@localhost:5432/ride_together
   JWT_SECRET=your_jwt_secret_here
   PORT=3001
   NODE_ENV=production
   ALLOWED_ORIGINS=https://your-domain.ru
   FRONTEND_URL=https://your-domain.ru
   ```

5. **Собрать проект**
   ```bash
   npm run build
   ```

6. **Запустить через PM2**
   ```bash
   pm2 start dist/index.js --name ride-backend
   pm2 save
   pm2 startup
   ```

---

### Этап 6: Деплой Frontend (20 минут)

**Вариант A: На том же VPS через Nginx**

1. **Собрать Frontend локально или на сервере**
   ```bash
   cd /var/www/ride-together
   npm install
   cp env.production.example .env.production
   # Обновить VITE_API_URL=https://your-domain.ru
   npm run build
   ```

2. **Настроить Nginx для статики**
   ```bash
   cp /var/www/ride-together/dist/* /var/www/html/
   ```

**Вариант B: На виртуальном хостинге REG.RU**

1. **Собрать Frontend локально**
   ```bash
   npm run build
   ```

2. **Загрузить dist/ через FTP или файловый менеджер**
   - Подключиться к виртуальному хостингу
   - Загрузить содержимое dist/ в public_html/

---

### Этап 7: Настройка Nginx (20 минут)

1. **Создать конфигурацию для Backend**
   ```bash
   nano /etc/nginx/sites-available/ride-backend
   ```

2. **Конфигурация:**
   ```nginx
   server {
       listen 80;
       server_name api.your-domain.ru;  # или your-domain.ru/api
       
       location / {
           proxy_pass http://localhost:3001;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```

3. **Конфигурация для Frontend:**
   ```nginx
   server {
       listen 80;
       server_name your-domain.ru;
       root /var/www/html;
       index index.html;
       
       # SPA routing
       location / {
           try_files $uri $uri/ /index.html;
       }
       
       # API proxy
       location /api {
           proxy_pass http://localhost:3001;
           proxy_http_version 1.1;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
       
       # WebSocket
       location /socket.io {
           proxy_pass http://localhost:3001;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection "upgrade";
           proxy_set_header Host $host;
       }
   }
   ```

4. **Активировать конфигурацию**
   ```bash
   ln -s /etc/nginx/sites-available/ride-backend /etc/nginx/sites-enabled/
   nginx -t
   systemctl reload nginx
   ```

---

### Этап 8: Настройка SSL (30 минут)

1. **Установить Certbot**
   ```bash
   apt install -y certbot python3-certbot-nginx
   ```

2. **Получить сертификат**
   ```bash
   certbot --nginx -d your-domain.ru -d api.your-domain.ru
   ```

3. **Автообновление**
   ```bash
   certbot renew --dry-run
   ```

---

### Этап 9: Тестирование (15 минут)

1. **Проверить Backend**
   ```bash
   curl http://localhost:3001/health
   curl https://api.your-domain.ru/health
   ```

2. **Проверить Frontend**
   - Открыть https://your-domain.ru в браузере
   - Проверить консоль на ошибки
   - Попробовать зарегистрироваться

3. **Проверить API**
   - Проверить запросы к API из Frontend
   - Проверить WebSocket соединение

---

### Этап 10: Обновление DNS (если нужно) (10 минут)

1. **Обновить A-запись** на IP VPS сервера
2. **Подождать распространения DNS** (до 24 часов, обычно быстрее)

---

## 🔧 Полезные команды после миграции

### Управление Backend
```bash
# Перезапуск
pm2 restart ride-backend

# Логи
pm2 logs ride-backend

# Статус
pm2 status
```

### Управление Nginx
```bash
# Перезагрузка
systemctl reload nginx

# Статус
systemctl status nginx

# Логи
tail -f /var/log/nginx/error.log
```

### Управление PostgreSQL
```bash
# Подключение
sudo -u postgres psql -d ride_together

# Бэкап
pg_dump -U ride_user ride_together > backup.sql

# Восстановление
psql -U ride_user ride_together < backup.sql
```

---

## 📊 Сравнение: Timeweb vs REG.RU

| Параметр | Timeweb Cloud | REG.RU |
|----------|---------------|--------|
| Backend | App Platform | VPS (настройка вручную) |
| Frontend | Static Hosting | VPS или виртуальный хостинг |
| БД | Managed PostgreSQL | Managed или на VPS |
| Сложность | ⭐ Простая | ⭐⭐ Средняя |
| Управление | Панель управления | SSH + панель |
| Автоматизация | twc CLI | Скрипты вручную |

---

## ✅ Чек-лист миграции

- [ ] Создан VPS на REG.RU
- [ ] Настроен SSH доступ
- [ ] Установлены необходимые пакеты (Node.js, PostgreSQL, Nginx)
- [ ] Экспортирована БД с Timeweb
- [ ] Импортирована БД на REG.RU
- [ ] Развернут Backend
- [ ] Развернут Frontend
- [ ] Настроен Nginx
- [ ] Настроен SSL
- [ ] Протестировано все функциональности
- [ ] Обновлен DNS
- [ ] Проверена работа в production

---

## 🆘 Возможные проблемы и решения

### Проблема: Backend не запускается
- Проверить логи: `pm2 logs ride-backend`
- Проверить переменные окружения
- Проверить порт 3001: `netstat -tulpn | grep 3001`

### Проблема: Nginx не работает
- Проверить конфигурацию: `nginx -t`
- Проверить логи: `tail -f /var/log/nginx/error.log`
- Проверить, что порты открыты: `ufw status`

### Проблема: База данных не подключается
- Проверить, запущен ли PostgreSQL: `systemctl status postgresql`
- Проверить права пользователя
- Проверить DATABASE_URL в .env.production

---

## 📝 Следующие шаги

После миграции:
1. Мониторинг работы приложения
2. Настройка автоматических бэкапов
3. Настройка мониторинга (если нужно)
4. Оптимизация производительности

