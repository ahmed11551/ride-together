# 🔧 Исправление ошибок переменных окружения

## Проблемы

1. **`VITE_API_URL is required in production`** - ошибка в консоли
2. **`Missing required Supabase environment variables`** - Supabase пытается инициализироваться без переменных
3. **`supabaseUrl is required`** - Supabase клиент создается с пустыми значениями

## Решения

### 1. Supabase сделан опциональным

**Файл:** `src/integrations/supabase/client.ts`

- ✅ Supabase клиент создается **только если** переменные установлены
- ✅ Если переменные не установлены, создается dummy клиент (не крашит приложение)
- ✅ Экспортируется флаг `isSupabaseConfigured` для проверки

### 2. Улучшена обработка VITE_API_URL

**Файл:** `src/lib/env.ts`

- ✅ Изменено `console.error` на `console.warn` для VITE_API_URL
- ✅ Приложение не крашится, если VITE_API_URL не установлен
- ✅ Логируется предупреждение, но приложение продолжает работать

## Что нужно сделать на Timeweb

### Обязательные переменные (для работы с backend):

```
VITE_API_URL=https://your-backend-url.twc1.net
VITE_WS_URL=wss://your-backend-url.twc1.net
```

### Опциональные переменные (только если используете Supabase):

```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-key
```

**ВАЖНО:** Если используете кастомный auth (не Supabase), то Supabase переменные можно НЕ указывать. Приложение будет работать без них.

## Проверка

После деплоя:
1. ✅ Нет ошибки `VITE_API_URL is required in production` (только предупреждение)
2. ✅ Нет ошибки `Missing required Supabase environment variables`
3. ✅ Нет ошибки `supabaseUrl is required`
4. ✅ Приложение загружается и работает

## Если используете кастомный auth

Если вы используете кастомный backend для auth (не Supabase), то:
- ✅ Укажите только `VITE_API_URL` и `VITE_WS_URL`
- ✅ Supabase переменные можно не указывать
- ✅ Приложение будет работать корректно

## Если используете Supabase

Если вы используете Supabase для auth:
- ✅ Укажите `VITE_SUPABASE_URL` и `VITE_SUPABASE_PUBLISHABLE_KEY`
- ✅ Также укажите `VITE_API_URL` для backend API (если есть)
- ✅ Приложение будет работать с обоими
