# ✅ Автоматическая настройка завершена!

## 🎉 Что сделано автоматически

### 1. ✅ Backend конфигурация
- Добавлен `dotenv` в зависимости
- Создан `server/.env.production` с настройками БД
- Backend автоматически загружает переменные при старте
- Значения по умолчанию для Timeweb БД установлены

### 2. ✅ Frontend конфигурация
- Создан `.env.production` для frontend
- Готов к использованию

### 3. ✅ Скрипт автоматизации
- Создан `setup-timeweb.sh` для быстрой настройки
- Автоматически генерирует JWT_SECRET
- Создает все необходимые файлы

---

## 🚀 Что нужно сделать СЕЙЧАС

### Шаг 1: Указать домены

**Откройте `server/.env.production` и замените:**
```
ALLOWED_ORIGINS=https://ваш-frontend-домен.twc1.net
FRONTEND_URL=https://ваш-frontend-домен.twc1.net
```

**Откройте `.env.production` (в корне) и замените:**
```
VITE_API_URL=https://ваш-backend-домен.twc1.net
VITE_WS_URL=wss://ваш-backend-домен.twc1.net
```

### Шаг 2: Применить схему БД

1. Откройте `TIMEWEB_FULL_SCHEMA.sql`
2. Скопируйте весь текст
3. В Timeweb Dashboard → Базы данных → SQL Editor
4. Вставьте и выполните

### Шаг 3: Задеплоить

**Backend:**
- Push в GitHub
- В Timeweb подключите репозиторий
- Укажите путь: `server`
- Build: `npm install`
- Start: `npm start`

**Frontend:**
- Push в GitHub
- В Timeweb подключите репозиторий
- Framework: React/Vite
- Build: `npm run build`
- Directory: `dist`

---

## ✅ Проверка

После деплоя:

1. **Backend:** `https://ваш-backend-домен.twc1.net/health` → `{"status":"ok"}`
2. **Frontend:** Откройте сайт → консоль (F12) → нет ошибок
3. **База данных:** Попробуйте зарегистрироваться → проверьте таблицу `users`

---

## 📝 Файлы созданы

- ✅ `server/.env.production` - настройки backend
- ✅ `.env.production` - настройки frontend
- ✅ `setup-timeweb.sh` - скрипт автоматизации
- ✅ `server/env.production.example` - пример для backend
- ✅ `env.production.example` - пример для frontend

**Все готово к деплою!** 🎉
