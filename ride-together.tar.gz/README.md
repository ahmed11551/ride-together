# Ride Together

Платформа для совместных поездок - найдите попутчиков или станьте водителем.

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
npm install
```

### 2. Настройка переменных окружения

Создайте `.env` файл:

```env
# Backend API (ОБЯЗАТЕЛЬНО)
VITE_API_URL=http://localhost:3001

# WebSocket (опционально)
VITE_WS_URL=ws://localhost:3001

# Яндекс.Карты (опционально)
VITE_YANDEX_MAPS_API_KEY=your-key

# Telegram Bot (опционально)
VITE_TELEGRAM_BOT_TOKEN=your-token

# Мониторинг (опционально)
VITE_SENTRY_DSN=your-sentry-dsn
```

### 3. Запуск в режиме разработки

```bash
npm run dev
```

Приложение будет доступно по адресу `http://localhost:8080`

## 📦 Сборка для production

```bash
npm run build
```

Файлы будут в папке `dist/`

## 🏗️ Архитектура

- **Frontend**: React + TypeScript + Vite
- **Backend**: Node.js + Express (в папке `server/`)
- **Database**: PostgreSQL на Timeweb Cloud
- **Deployment**: Timeweb Cloud (App Platform + Static Hosting)

## 📚 Документация

- **Деплой на Timeweb**: `START_HERE_TIMEWEB.md`
- **Быстрый деплой**: `TIMEWEB_QUICK_DEPLOY.md`
- **Подробная инструкция**: `TIMEWEB_FULL_DEPLOY.md`
- **Краткая инструкция**: `КОПИРУЙ_В_TIMEWEB_ПОЛНЫЙ.txt`

## 🛠️ Технологии

- React 18.3.1
- TypeScript 5.8.3
- Vite 5.4.19
- Tailwind CSS 3.4.17
- shadcn/ui
- React Router 6.30.1
- React Query 5.83.0
- Yandex Maps API

## 📝 Скрипты

- `npm run dev` - Запуск в режиме разработки
- `npm run build` - Сборка для production
- `npm run preview` - Предпросмотр production сборки
- `npm run lint` - Проверка кода
- `npm test` - Запуск тестов

## 🔧 Полезные скрипты

- `./scripts/build-for-timeweb.sh` - Сборка для деплоя на Timeweb
- `./scripts/prepare-deploy.sh` - Подготовка к деплою
- `./scripts/check-deploy.sh` - Проверка готовности

## 📖 Структура проекта

```
ride-together/
├── server/          # Backend (Node.js/Express)
├── src/             # Frontend (React)
├── public/          # Статические файлы
├── scripts/         # Вспомогательные скрипты
└── dist/            # Собранный фронтенд (после build)
```

## 🚀 Деплой

См. `START_HERE_TIMEWEB.md` для инструкций по деплою на Timeweb.

## 📄 Лицензия

MIT
