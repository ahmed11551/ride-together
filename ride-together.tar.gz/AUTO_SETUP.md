# 🤖 Автоматическая настройка для Timeweb

## ✅ Что уже сделано автоматически

### 1. Backend конфигурация

✅ **Автоматическая загрузка переменных окружения:**
- Файл `server/.env.production` создан с настройками БД
- Backend автоматически загружает переменные при старте
- Значения по умолчанию установлены для Timeweb БД

✅ **Что нужно изменить:**

1. **Откройте `server/.env.production`**
2. **Замените `JWT_SECRET`** на свой секретный ключ:
   ```bash
   openssl rand -base64 32
   ```
3. **Замените `ALLOWED_ORIGINS` и `FRONTEND_URL`** на ваш реальный frontend домен

### 2. Frontend конфигурация

✅ **Файл `.env.production` создан**
- Нужно только указать ваш backend URL

✅ **Что нужно изменить:**

1. **Откройте `.env.production`** (в корне проекта)
2. **Замените `VITE_API_URL` и `VITE_WS_URL`** на ваш реальный backend домен

### 3. База данных

✅ **Схема готова:**
- Файл `TIMEWEB_FULL_SCHEMA.sql` готов к применению
- Просто скопируйте и выполните в SQL Editor Timeweb

---

## 🚀 Быстрая настройка

### Шаг 1: Backend

1. Откройте `server/.env.production`
2. Сгенерируйте JWT_SECRET:
   ```bash
   openssl rand -base64 32
   ```
3. Замените в файле:
   ```
   JWT_SECRET=ваш-сгенерированный-ключ
   ALLOWED_ORIGINS=https://ваш-frontend-домен.twc1.net
   FRONTEND_URL=https://ваш-frontend-домен.twc1.net
   ```

### Шаг 2: Frontend

1. Откройте `.env.production` (в корне)
2. Замените:
   ```
   VITE_API_URL=https://ваш-backend-домен.twc1.net
   VITE_WS_URL=wss://ваш-backend-домен.twc1.net
   ```

### Шаг 3: База данных

1. Откройте `TIMEWEB_FULL_SCHEMA.sql`
2. Скопируйте весь текст
3. В Timeweb Dashboard → Базы данных → SQL Editor
4. Вставьте и выполните

---

## 📦 Деплой

### Backend

1. **Push в GitHub** (файлы уже готовы)
2. **В Timeweb Dashboard:**
   - Подключите репозиторий
   - Укажите путь: `server`
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Timeweb автоматически подхватит `.env.production`

### Frontend

1. **Push в GitHub**
2. **В Timeweb Dashboard:**
   - Framework: React/Vite
   - Build Command: `npm run build`
   - Build Directory: `dist`
   - Timeweb автоматически подхватит `.env.production`

---

## ✅ Проверка

После деплоя:

1. **Backend:** `https://ваш-backend-домен.twc1.net/health` → должно вернуть `{"status":"ok"}`
2. **Frontend:** Откройте сайт → проверьте консоль (F12) → не должно быть ошибок
3. **База данных:** Попробуйте зарегистрироваться → проверьте таблицу `users` в БД

---

## 🔧 Если что-то не работает

### Backend не подключается к БД:

1. Проверьте `server/.env.production` - правильный ли `DATABASE_URL`
2. Проверьте логи деплоя в Timeweb
3. Убедитесь, что SSL сертификат доступен (если требуется)

### Frontend не подключается к Backend:

1. Проверьте `.env.production` - правильный ли `VITE_API_URL`
2. Проверьте CORS на backend - правильный ли `ALLOWED_ORIGINS`
3. Проверьте, что backend запущен и доступен

### База данных пустая:

1. Убедитесь, что применили `TIMEWEB_FULL_SCHEMA.sql`
2. Проверьте в SQL Editor: `SELECT * FROM users LIMIT 1;`
