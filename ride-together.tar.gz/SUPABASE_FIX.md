# 🔧 Исправление ошибки Supabase

## Проблема

```
ReferenceError: exports is not defined
at http://localhost:8080/node_modules/@supabase/supabase-js/dist/main/index.js
```

## Причина

Supabase использует CommonJS (`exports`), а Vite использует ESM. Нужно правильно настроить Vite для преобразования CommonJS в ESM.

## Решение

### 1. Добавлен Supabase в `optimizeDeps.include`

```typescript
optimizeDeps: {
  include: [
    // ... другие зависимости
    '@supabase/supabase-js', // Включаем Supabase для правильной обработки CommonJS
  ],
  esbuildOptions: {
    target: 'esnext',
    jsx: 'automatic',
    format: 'esm', // Преобразуем CommonJS в ESM
  },
}
```

### 2. Добавлены условия разрешения модулей

```typescript
resolve: {
  alias: {
    "@": path.resolve(__dirname, "./src"),
  },
  conditions: ['import', 'module', 'browser', 'default'],
}
```

## Что это делает

1. **`optimizeDeps.include`** - Vite предварительно обработает Supabase и преобразует CommonJS в ESM
2. **`format: 'esm'`** - esbuild преобразует CommonJS модули в ESM формат
3. **`conditions`** - Правильный порядок разрешения модулей для браузера

## Проверка

После перезапуска dev сервера:
1. Ошибка `exports is not defined` должна исчезнуть
2. Supabase должен работать корректно
3. Приложение должно загружаться без ошибок

## Если проблема осталась

Попробуйте:
1. Очистить кэш: `rm -rf node_modules/.vite`
2. Перезапустить dev сервер
3. Проверить, что `.env` файл содержит правильные переменные Supabase (или они не нужны, если используется кастомный auth)
