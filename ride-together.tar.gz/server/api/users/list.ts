/**
 * API endpoint для получения списка всех пользователей (admin only)
 * GET /api/users
 */

import { db } from '../../utils/database';
import { extractTokenFromHeader, verifyToken } from '../../utils/jwt';

export async function listUsers(req: Request): Promise<Response> {
  try {
    const authHeader = req.headers.get('authorization');
    const token = extractTokenFromHeader(authHeader);
    const payload = verifyToken(token || '');

    if (!payload || !payload.userId) {
      return new Response(
        JSON.stringify({ error: 'Не авторизован' }),
        { status: 401, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Проверяем, является ли пользователь админом
    const adminCheck = await db.query(
      'SELECT is_admin FROM profiles WHERE user_id = $1',
      [payload.userId]
    );

    if (!adminCheck.rows[0]?.is_admin) {
      return new Response(
        JSON.stringify({ error: 'Доступ запрещен' }),
        { status: 403, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Получаем всех пользователей с их профилями
    const result = await db.query(
      `SELECT 
        user_id,
        full_name,
        phone,
        avatar_url,
        rating,
        passenger_rating,
        trips_count,
        is_verified,
        is_admin,
        is_banned,
        created_at
      FROM profiles
      ORDER BY created_at DESC`
    );

    const users = result.rows.map(row => ({
      user_id: row.user_id,
      full_name: row.full_name,
      email: null, // Email не хранится в profiles, только в auth.users (для будущего)
      phone: row.phone,
      avatar_url: row.avatar_url,
      rating: parseFloat(row.rating || '5.0'),
      trips_count: row.trips_count || 0,
      is_verified: row.is_verified || false,
      is_admin: row.is_admin || false,
      is_banned: row.is_banned || false,
      created_at: row.created_at,
    }));

    return new Response(
      JSON.stringify(users),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error: any) {
    console.error('List users error:', error);
    return new Response(
      JSON.stringify({ error: 'Ошибка при получении списка пользователей' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

