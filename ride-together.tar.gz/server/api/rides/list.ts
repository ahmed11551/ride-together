/**
 * API endpoint для получения списка поездок
 * GET /api/rides
 */

import { db } from '../../utils/database';
import { extractTokenFromHeader, verifyToken } from '../../utils/jwt';

export async function listRides(req: Request): Promise<Response> {
  try {
    const authHeader = req.headers.get('authorization');
    const token = extractTokenFromHeader(authHeader);
    const userId = token ? verifyToken(token)?.userId : null;

    const url = new URL(req.url);
    const from = url.searchParams.get('from');
    const to = url.searchParams.get('to');
    const date = url.searchParams.get('date');
    const passengers = parseInt(url.searchParams.get('passengers') || '1');
    const status = url.searchParams.get('status') || 'active';
    
    // Поддержка пагинации: page/pageSize или limit/offset
    const page = parseInt(url.searchParams.get('page') || '0');
    const pageSize = parseInt(url.searchParams.get('pageSize') || '0');
    const limit = pageSize > 0 ? pageSize : parseInt(url.searchParams.get('limit') || '50');
    const offset = page > 0 && pageSize > 0 
      ? (page - 1) * pageSize 
      : parseInt(url.searchParams.get('offset') || '0');
    
    // Флаг для возврата метаданных пагинации
    const includePagination = url.searchParams.get('includePagination') === 'true' || 
                               (page > 0 && pageSize > 0);

    // Базовый запрос для подсчета общего количества
    let countQuery = `
      SELECT COUNT(*) as total
      FROM rides r
      WHERE r.status = $1
        AND r.seats_available >= $2
    `;
    const countParams: any[] = [status, passengers];

    // Фильтры для подсчета
    if (from) {
      countParams.push(`%${from}%`);
      countQuery += ` AND r.from_city ILIKE $${countParams.length}`;
    }
    if (to) {
      countParams.push(`%${to}%`);
      countQuery += ` AND r.to_city ILIKE $${countParams.length}`;
    }
    if (date) {
      countParams.push(date);
      countQuery += ` AND r.departure_date = $${countParams.length}`;
    }

    // Базовый запрос для данных
    let query = `
      SELECT 
        r.*,
        p.full_name as driver_full_name,
        p.avatar_url as driver_avatar_url,
        p.rating as driver_rating,
        p.trips_count as driver_trips_count,
        p.is_verified as driver_is_verified
      FROM rides r
      LEFT JOIN profiles p ON r.driver_id = p.user_id
      WHERE r.status = $1
        AND r.seats_available >= $2
    `;
    const params: any[] = [status, passengers];

    // Фильтры
    if (from) {
      params.push(`%${from}%`);
      query += ` AND r.from_city ILIKE $${params.length}`;
    }
    if (to) {
      params.push(`%${to}%`);
      query += ` AND r.to_city ILIKE $${params.length}`;
    }
    if (date) {
      params.push(date);
      query += ` AND r.departure_date = $${params.length}`;
    }

    // Сортировка
    // Для recent rides сортируем по created_at DESC, для search - по departure_date ASC
    const sortBy = url.searchParams.get('sortBy') || 'departure';
    if (sortBy === 'recent' || sortBy === 'created_at') {
      query += ` ORDER BY r.created_at DESC`;
    } else {
      query += ` ORDER BY r.departure_date ASC, r.departure_time ASC`;
    }

    // Лимит и оффсет
    params.push(limit, offset);
    query += ` LIMIT $${params.length - 1} OFFSET $${params.length}`;

    // Выполняем запросы
    const [countResult, dataResult] = await Promise.all([
      includePagination ? db.query(countQuery, countParams) : Promise.resolve({ rows: [{ total: 0 }] }),
      db.query(query, params)
    ]);

    const total = includePagination ? parseInt(countResult.rows[0].total) : 0;
    const totalPages = includePagination && pageSize > 0 ? Math.ceil(total / pageSize) : 0;

    const rides = dataResult.rows.map(row => ({
      id: row.id,
      driver_id: row.driver_id,
      from_city: row.from_city,
      from_address: row.from_address,
      to_city: row.to_city,
      to_address: row.to_address,
      departure_date: row.departure_date,
      departure_time: row.departure_time,
      estimated_duration: row.estimated_duration,
      price: parseFloat(row.price),
      seats_total: row.seats_total,
      seats_available: row.seats_available,
      status: row.status,
      allow_smoking: row.allow_smoking,
      allow_pets: row.allow_pets,
      allow_music: row.allow_music,
      notes: row.notes,
      created_at: row.created_at,
      updated_at: row.updated_at,
      driver: row.driver_full_name ? {
        full_name: row.driver_full_name,
        avatar_url: row.driver_avatar_url,
        rating: parseFloat(row.driver_rating || '5.0'),
        trips_count: row.driver_trips_count || 0,
        is_verified: row.driver_is_verified || false,
      } : undefined,
    }));

    // Если запрошена пагинация, возвращаем объект с метаданными
    if (includePagination) {
      const currentPage = page > 0 ? page : 1;
      const currentPageSize = pageSize > 0 ? pageSize : limit;
      return new Response(
        JSON.stringify({
          data: rides,
          total,
          page: currentPage,
          pageSize: currentPageSize,
          totalPages,
          hasMore: currentPage < totalPages,
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Иначе возвращаем просто массив (обратная совместимость)
    return new Response(
      JSON.stringify(rides),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error: any) {
    console.error('List rides error:', error);
    return new Response(
      JSON.stringify({ error: 'Ошибка при получении списка поездок' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

