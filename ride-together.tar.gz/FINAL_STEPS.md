# ✅ Финальные шаги для деплоя

## ✅ Шаг 1: Схема БД - ГОТОВО!

Вы уже скопировали `TIMEWEB_FULL_SCHEMA.sql`. Теперь:

1. **Откройте Timeweb Dashboard**
2. **Перейдите в раздел "Базы данных"** или **"Databases"**
3. **Найдите вашу базу данных** `default_db`
4. **Откройте "SQL Editor"** или **"Query Editor"**
5. **Вставьте скопированный SQL код**
6. **Нажмите "Выполнить"** или **"Run"**
7. **Дождитесь завершения** - должно быть сообщение об успехе

**Проверка:**
После выполнения, проверьте что таблицы созданы:
```sql
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;
```

Должны быть таблицы: `users`, `sessions`, `profiles`, `rides`, `bookings`, и т.д.

---

## 🔧 Шаг 2: Проверьте переменные окружения

### Backend (`server/.env.production`)

Убедитесь, что указаны правильные домены:

```bash
# Database (уже настроено)
DATABASE_URL=postgresql://gen_user:fn)un5%40K2oLrBJ@9d497bc2bf9dd679bd9834af.twc1.net:5432/default_db?sslmode=verify-full

# JWT (уже сгенерирован)
JWT_SECRET=... (должен быть длинный случайный ключ)

# CORS - ЗАМЕНИТЕ на ваш реальный frontend домен!
ALLOWED_ORIGINS=https://ваш-frontend-домен.twc1.net
FRONTEND_URL=https://ваш-frontend-домен.twc1.net
```

### Frontend (`.env.production` в корне)

Убедитесь, что указан правильный backend URL:

```bash
# ЗАМЕНИТЕ на ваш реальный backend домен!
VITE_API_URL=https://ваш-backend-домен.twc1.net
VITE_WS_URL=wss://ваш-backend-домен.twc1.net
```

---

## 🚀 Шаг 3: Деплой Backend

### В Timeweb Dashboard:

1. **Создайте/откройте Node.js приложение** для backend
2. **Подключите GitHub репозиторий**
3. **Настройки деплоя:**
   - **Путь к проекту:** `server` (если нужно)
   - **Build Command:** `npm install` (или `cd server && npm install`)
   - **Start Command:** `npm start` (или `cd server && npm start`)
   - **Node.js Version:** `20` или `22`
   - **Working Directory:** `server` (если нужно)

4. **Environment Variables** (если Timeweb поддерживает):
   - Добавьте переменные из `server/.env.production`
   - Или Timeweb автоматически подхватит `.env.production` файл

5. **Запустите деплой**

### Проверка Backend:

После деплоя, откройте:
```
https://ваш-backend-домен.twc1.net/health
```

Должно вернуть:
```json
{"status":"ok","timestamp":"2024-..."}
```

---

## 🎨 Шаг 4: Деплой Frontend

### В Timeweb Dashboard:

1. **Создайте/откройте Static Site** или **React App**
2. **Подключите GitHub репозиторий**
3. **Настройки деплоя:**
   - **Framework:** `React` или `Vite` или `Static Site`
   - **Build Command:** `npm run build`
   - **Build Directory:** `dist`
   - **Node.js Version:** `20` или `22`

4. **Environment Variables** (если Timeweb поддерживает):
   - Добавьте переменные из `.env.production`
   - Или Timeweb автоматически подхватит `.env.production` файл

5. **Запустите деплой**

### Проверка Frontend:

После деплоя:
1. Откройте сайт в браузере
2. Откройте DevTools (F12) → Console
3. Проверьте, что нет ошибок:
   - ❌ Нет `__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED`
   - ❌ Нет `exports is not defined`
   - ❌ Нет ошибок подключения к backend
4. Попробуйте зарегистрироваться/войти

---

## ✅ Финальная проверка

### 1. База данных
```sql
-- Проверьте что таблицы созданы
SELECT COUNT(*) FROM users;
SELECT COUNT(*) FROM rides;
SELECT COUNT(*) FROM bookings;
```

### 2. Backend
- ✅ `/health` endpoint работает
- ✅ Нет ошибок в логах
- ✅ Подключение к БД успешно

### 3. Frontend
- ✅ Сайт загружается
- ✅ Нет ошибок в консоли
- ✅ Можно зарегистрироваться
- ✅ Можно войти

---

## 🆘 Если что-то не работает

### Backend не подключается к БД:
- Проверьте `DATABASE_URL` в `server/.env.production`
- Проверьте логи деплоя в Timeweb
- Убедитесь, что схема БД применена

### Frontend не подключается к Backend:
- Проверьте `VITE_API_URL` в `.env.production`
- Проверьте CORS на backend (`ALLOWED_ORIGINS`)
- Проверьте, что backend запущен

### Ошибки в консоли браузера:
- Проверьте, что все chunks загружаются
- Проверьте Network tab - все запросы должны быть успешными
- Проверьте, что переменные окружения применены

---

## 🎉 Готово!

После выполнения всех шагов, ваше приложение должно работать на Timeweb!

Если возникнут проблемы - проверьте логи в Timeweb Dashboard и сообщите об ошибках.
