# ⚡ Быстрый деплой всего на Timeweb

## 🎯 Все в одном месте: Фронтенд + Бэкенд на Timeweb

## Шаг 1: База данных (5 минут)

1. Timeweb Cloud → Создать PostgreSQL
2. SQL Editor → Скопировать `TIMEWEB_FULL_SCHEMA.sql` → Выполнить

## Шаг 2: Бэкенд (10 минут)

1. **Создайте `server/.env`:**
   ```bash
   cd server
   cp env.example .env
   # Отредактируйте .env с данными БД
   ```

2. **В Timeweb App Platform:**
   - Создать приложение
   - GitHub репозиторий
   - Root: `server`
   - Build: `npm install && npm run build`
   - Start: `npm start`
   - Port: `3001`
   - Добавить переменные из `.env`

3. **Запишите URL бэкенда** (например: `https://api-12345.twc1.net`)

## Шаг 3: Фронтенд (10 минут)

### Вариант A: Статический хостинг

1. **Соберите фронтенд:**
   ```bash
   # В корне проекта
   ./scripts/build-for-timeweb.sh
   # Или вручную:
   # Создайте .env с VITE_API_URL=https://your-backend-url
   # npm install && npm run build
   ```

2. **В Timeweb Static Hosting:**
   - Создать статический сайт
   - Загрузить содержимое папки `dist/`

### Вариант B: App Platform

1. **В Timeweb App Platform:**
   - Создать новое приложение
   - GitHub репозиторий
   - Root: `.` (корень)
   - Build: `npm install && npm run build`
   - Start: `npx serve -s dist -l 3000`
   - Port: `3000`
   - Environment Variables:
     ```
     VITE_API_URL=https://your-backend-url.twc1.net
     VITE_WS_URL=wss://your-backend-url.twc1.net
     ```

## Шаг 4: Обновление CORS (2 минуты)

После получения домена фронтенда:

1. В бэкенд приложении обновите `ALLOWED_ORIGINS`:
   ```
   https://your-frontend-domain.twc1.net
   ```

2. Перезапустите бэкенд

## ✅ Готово!

Откройте домен фронтенда и проверьте работу.

## Преимущества

✅ Все в одном месте  
✅ Нет проблем с CORS  
✅ Проще управление  
✅ Единый биллинг  
✅ Быстрая связь между сервисами  

## Структура

```
Timeweb Cloud:
├── PostgreSQL Database
├── Backend App (App Platform)
│   └── server/ (Node.js/Express на порту 3001)
└── Frontend (Static Hosting или App Platform)
    └── dist/ (React build на порту 3000 или статический)
```

## Troubleshooting

### Фронтенд не подключается к API
- Проверьте `VITE_API_URL` в переменных окружения
- Убедитесь, что бэкенд доступен

### Ошибки 404 на роутах
- Убедитесь, что настроен SPA режим (все запросы на `index.html`)
- Для статического хостинга: скопируйте `.htaccess` в `dist/`

### CORS ошибки
- Обновите `ALLOWED_ORIGINS` на бэкенде
- Перезапустите бэкенд
