# 📋 Пошаговая инструкция: Деплой бэкенда на Timeweb

## Шаг 1: Подготовка файлов

### 1.1 Создайте `.env` файл в папке `server`

```bash
cd server
cp env.example .env
```

### 1.2 Заполните `.env` файл

Откройте `server/.env` и заполните следующие значения:

```env
# Database Configuration (Timeweb PostgreSQL)
TIMEWEB_DB_HOST=your-timeweb-db-host.twc1.net
TIMEWEB_DB_PORT=5432
TIMEWEB_DB_NAME=default_db
TIMEWEB_DB_USER=gen_user
TIMEWEB_DB_PASSWORD=your-password-here

# SSL Configuration
TIMEWEB_DB_SSL=true
TIMEWEB_DB_SSL_CERT=./ca.crt
TIMEWEB_DB_SSL_MODE=verify-full

# Server Configuration
PORT=3001
NODE_ENV=production

# JWT Configuration
# ВАЖНО: Сгенерируйте секретный ключ командой: openssl rand -base64 32
JWT_SECRET=your-generated-secret-key-here-min-32-chars
JWT_EXPIRES_IN=7d

# CORS Configuration
# Пока оставьте пустым или добавьте localhost для тестирования
# После деплоя Vercel обновите на ваш домен
ALLOWED_ORIGINS=http://localhost:8080,http://localhost:5173

# WebSocket Configuration
WS_PORT=3001
```

**Где взять данные БД:**
1. Откройте [Timeweb Cloud](https://timeweb.cloud/my/projects/2005839)
2. Перейдите в ваш проект → База данных → PostgreSQL
3. Скопируйте данные подключения:
   - Host (например: `9d497bc2bf9dd679bd9834af.twc1.net`)
   - Port (обычно `5432`)
   - Database (обычно `default_db`)
   - User (обычно `gen_user`)
   - Password (скопируйте из настроек)

**Генерация JWT_SECRET:**
```bash
openssl rand -base64 32
```

### 1.3 Скопируйте SSL сертификат

```bash
# Убедитесь, что ca.crt находится в папке server
cp ../ca.crt ./ca.crt
```

## Шаг 2: Деплой через Timeweb App Platform

### 2.1 Создание приложения

1. Откройте [Timeweb Cloud](https://timeweb.cloud/my/projects/2005839)
2. Нажмите **"Создать"** → **"Приложение"** (App Platform)
3. Выберите **"Из Git репозитория"** или **"Из архива"**

### 2.2 Настройка из Git репозитория (рекомендуется)

1. **Подключите репозиторий:**
   - Выберите ваш GitHub репозиторий
   - Укажите ветку (обычно `main` или `master`)
   - **Root Directory**: `ride-together/server` (если репозиторий корневой) или `server` (если репозиторий только с server)

2. **Настройки сборки:**
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   - **Port**: `3001`

3. **Переменные окружения:**
   - Нажмите **"Переменные окружения"**
   - Добавьте все переменные из вашего `.env` файла:
     ```
     TIMEWEB_DB_HOST=...
     TIMEWEB_DB_PORT=5432
     TIMEWEB_DB_NAME=...
     TIMEWEB_DB_USER=...
     TIMEWEB_DB_PASSWORD=...
     TIMEWEB_DB_SSL=true
     TIMEWEB_DB_SSL_CERT=./ca.crt
     TIMEWEB_DB_SSL_MODE=verify-full
     PORT=3001
     NODE_ENV=production
     JWT_SECRET=...
     JWT_EXPIRES_IN=7d
     ALLOWED_ORIGINS=http://localhost:8080
     WS_PORT=3001
     ```

4. **Файлы:**
   - Убедитесь, что `ca.crt` загружен в репозиторий или добавлен через интерфейс Timeweb

5. **Создайте приложение**

### 2.3 Настройка из архива (альтернатива)

1. Создайте архив:
   ```bash
   cd server
   tar -czf ../server-deploy.tar.gz . --exclude=node_modules --exclude=.git
   ```

2. В Timeweb:
   - Выберите **"Из архива"**
   - Загрузите `server-deploy.tar.gz`
   - Настройте переменные окружения (как в шаге 2.2.3)
   - Настройте Build и Start команды

## Шаг 3: Проверка деплоя

### 3.1 Проверка health endpoint

После деплоя откройте в браузере или через curl:

```bash
curl https://your-app-url.twc1.net/health
```

Должен вернуться:
```json
{"status":"ok","timestamp":"2024-01-31T..."}
```

### 3.2 Проверка логов

1. В Timeweb Cloud → Ваше приложение → **"Логи"**
2. Проверьте, что нет ошибок подключения к БД
3. Убедитесь, что сервер запустился: `🚀 Server running on port 3001`

### 3.3 Тестирование API

```bash
# Тест регистрации
curl -X POST https://your-app-url.twc1.net/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123","fullName":"Test User"}'
```

## Шаг 4: Получение URL бэкенда

После успешного деплоя:

1. В Timeweb Cloud → Ваше приложение → **"Домены"**
2. Запишите URL (например: `https://api-12345.twc1.net`)
3. Этот URL понадобится для настройки фронтенда

## Шаг 5: Обновление CORS (после деплоя Vercel)

После того, как задеплоите фронтенд на Vercel:

1. Получите домен Vercel (например: `your-app.vercel.app`)
2. В Timeweb Cloud → Ваше приложение → **"Переменные окружения"**
3. Обновите `ALLOWED_ORIGINS`:
   ```
   ALLOWED_ORIGINS=https://your-app.vercel.app,https://www.your-app.vercel.app
   ```
4. Перезапустите приложение

## Troubleshooting

### Ошибка подключения к БД

**Проблема**: `Connection refused` или `SSL error`

**Решение**:
1. Проверьте правильность хоста, порта, имени БД, пользователя и пароля
2. Убедитесь, что `ca.crt` доступен в приложении
3. Проверьте `TIMEWEB_DB_SSL=true` и `TIMEWEB_DB_SSL_MODE=verify-full`

### Ошибка сборки

**Проблема**: Build failed

**Решение**:
1. Проверьте логи сборки в Timeweb
2. Убедитесь, что `package.json` содержит скрипт `build`
3. Проверьте, что все зависимости указаны в `dependencies`, а не только в `devDependencies`

### Порт не открыт

**Проблема**: Приложение не отвечает

**Решение**:
1. Убедитесь, что в настройках указан правильный порт (`3001`)
2. Проверьте, что приложение слушает на `0.0.0.0`, а не на `localhost`

### CORS ошибки

**Проблема**: `Access-Control-Allow-Origin` ошибка

**Решение**:
1. Проверьте `ALLOWED_ORIGINS` - должен содержать точный домен Vercel с `https://`
2. Перезапустите приложение после изменения переменных

## Полезные команды для локального тестирования

```bash
# Установка зависимостей
cd server
npm install

# Локальный запуск
npm run dev

# Сборка
npm run build

# Запуск production версии
npm start
```

## Следующий шаг

После успешного деплоя бэкенда переходите к деплою фронтенда на Vercel (см. `VERCEL_DEPLOY_STEP_BY_STEP.md`).
